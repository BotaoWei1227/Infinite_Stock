import test from "node:test";import assert from "node:assert";
import {route,tick} from "../src/app.js";import {HttpError} from "../src/errors.js";import {fakeDb} from "./helpers.js";
const env={ALLOWED_ORIGIN:"https://u.github.io"},H=3600e3,DAYMS=864e5;
function mk(o={}){
  const t={v:1.8e12},db=fakeDb(),state={provider:"google.com",uid:"g1",name:"Botao",email:"player@example.com",emailVerified:true,noSeed:false};
  const d={db,now:()=>t.v,rand:()=>.5,
    verify:async()=>({uid:state.uid,provider:state.provider,name:state.name,email:state.email,emailVerified:state.emailVerified}),...o};
  // 投入元素需要背包裡有同名元素：測試預設在每次 /inject 前補 1 個（state.noSeed=true 可關掉，用來測「沒有元素」）
  const call=async(p,body)=>{
    if(p==="/inject"&&!state.noSeed&&body?.stockId){const k=`players/${state.uid}`,cur=db.m.get(k);
      if(cur){if(!(Number(cur.data.inv?.[body.stockId])>=1))cur.data.inv={...(cur.data.inv||{}),[body.stockId]:1};}
      else db.m.set(k,{v:"seed"+state.uid,data:{cash:50,hold:{},name:state.name,inv:{[body.stockId]:1}}});}
    const r=await route(new Request("https://w"+p,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body||{})}),env,d);return {status:r.status,body:await r.json(),h:r.headers};};
  return {d,db,t,state,call};
}
const inj=(x={})=>({stockId:"fire",...x});
const TR=(x={})=>({stockId:"fire",dir:1,...x});
const BK=(x={})=>({...x});
const MS=db=>db.m.get("market/state").data.stocks;
import * as L from "../src/logic.js";
const OD=db=>db.m.get("secret/odds").data;                 // 私密文件：機率偏移與活動影響
const BIAS=(db,id="fire")=>OD(db).bias[id]?.v??0;           // 已寫入的偏移值（寫入當下）
const EFF=(x,id="fire")=>L.effOdds(OD(x.db).bias[id],x.t.v); // 「現在」衰減後的偏移
const P=db=>db.m.get("players/g1").data;
const feeds=db=>[...db.m].filter(([k])=>k.startsWith("feed/")).map(([,v])=>v.data);

test("市場初始化（只做一次）",async()=>{
  const {call,db}=mk();await call("/ensure-market");await call("/ensure-market");
  assert.equal(Object.keys(MS(db)).length,6);assert.equal(MS(db).fire.t.length,1);
});
test("投入元素：只改變機率、價格不跳動；消耗 1 個元素；動態寫好；CORS 正確",async()=>{
  const {call,db}=mk();await call("/ensure-market");
  const r=await call("/inject",inj());
  assert.equal(r.status,200);assert.equal("up" in r.body,false);assert.equal(r.body.price,12);assert.equal(r.body.tier,"basic");assert.equal(r.body.left,0);
  assert.equal(r.h.get("Access-Control-Allow-Origin"),"https://u.github.io");
  const f=MS(db).fire;assert.ok(Math.abs(BIAS(db)-.025)<1e-9);assert.equal("bias" in f,false);assert.equal("biasAt" in f,false);assert.deepEqual(f.p,[12]);assert.equal(f.t.length,1);assert.equal(f.last,"🔥火 元素");   // 沒有新的價格點
  assert.equal(MS(db).water.price,10);
  assert.equal(P(db).name,"Botao");assert.equal(P(db).cash,50);assert.equal(P(db).inv.fire,0);
  const fd=feeds(db)[0];assert.equal("up" in fd,false);assert.equal(fd.element,true);assert.equal(fd.tier,"basic");assert.equal(fd.stock,"火");
  assert.equal(db.m.has("links/g1"),false);assert.equal(db.m.has("iaLinks/iau_1"),false);                 // 不再綁定無限煉製
});
test("投入元素：蒸氣／雷滿額 +5 個百分點、基礎元素一半；沒有元素不能投、不是元素的股票代號被拒絕",async()=>{
  const {call,db,state,t}=mk();await call("/ensure-market");
  assert.equal((await call("/inject",inj({stockId:"steam"}))).body.tier,"crafted");t.v+=9000;assert.ok(Math.abs(BIAS(db,"steam")-.05)<1e-9);
  assert.equal((await call("/inject",inj({stockId:"wind"}))).body.tier,"basic");assert.ok(Math.abs(BIAS(db,"wind")-.025)<1e-9);t.v+=9000;
  state.noSeed=true;const r=await call("/inject",inj({stockId:"water"}));assert.equal(r.status,409);assert.match(r.body.error.message,/沒有「水」元素/);
  assert.equal((await call("/inject",inj({stockId:"nope"}))).status,400);assert.equal((await call("/inject",{})).status,400);
});
test("排程：每檔隨機走一步，偏移衰減；衝突會重試；缺市場時會建立",async()=>{
  const {call,db,d,t}=mk();await call("/ensure-market");await call("/inject",inj());
  t.v+=5*60*1000;await tick(d);
  const f=MS(db).fire;assert.equal(f.t.length,2);assert.ok(Math.abs(BIAS(db)-.025)<1e-9);assert.equal("bias" in f,false);assert.equal(MS(db).water.t.length,2);
  db.failNext=2;await tick(d);assert.equal(MS(db).water.t.length,3);
  const e=mk();await tick(e.d);assert.equal(Object.keys(MS(e.db)).length,6);
});
test("未登入 / 非 Google 提供者 → 401",async()=>{
  const a=mk();a.state.provider="anonymous";
  for(const [p,b] of [["/inject",inj()],["/trade",TR()],["/bank",BK({action:"borrow",amount:5})]])assert.equal((await a.call(p,b)).status,401);
  const b=mk({verify:async()=>{throw new HttpError(401,"unauthenticated","x");}});assert.equal((await b.call("/trade",{})).status,401);
});
test("冷卻 8 秒",async()=>{
  const {call,t}=mk();await call("/ensure-market");await call("/inject",inj());
  assert.equal((await call("/inject",inj())).status,429);
  t.v+=9000;assert.equal((await call("/inject",inj({stockId:"thunder"}))).status,200);
});
test("買賣與銀行只需要 Google 登入",async()=>{
  const {call,db}=mk();await call("/ensure-market");
  for(let i=0;i<4;i++)assert.equal((await call("/trade",TR())).status,200);
  assert.deepEqual(P(db),{name:"Botao",cash:2,hold:{fire:4}});
  assert.equal((await call("/trade",TR())).status,409);
  assert.equal((await call("/trade",TR({stockId:"water",dir:-1}))).status,409);
  assert.equal((await call("/bank",BK({action:"borrow",amount:10}))).status,200);
});
test("樂觀鎖衝突會自動重試",async()=>{
  const {call,db}=mk();await call("/ensure-market");db.failNext=2;
  assert.equal((await call("/trade",TR())).status,200);
});
test("參數檢查與 OPTIONS",async()=>{
  const {call,d}=mk();await call("/ensure-market");
  assert.equal((await call("/inject",inj({stockId:"../x"}))).status,400);
  assert.equal((await call("/trade",TR({dir:5}))).status,400);
  assert.equal((await route(new Request("https://w/inject",{method:"OPTIONS"}),env,d)).status,204);
});
test("元素是消耗品：投入一次用掉 1 個，沒了就不能投；背包有幾個就能投幾次（隔 8 秒）",async()=>{
  const {call,db,t,state}=mk();await call("/ensure-market");state.noSeed=true;
  db.m.set("players/g1",{v:"s1",data:{cash:50,hold:{},name:"Botao",inv:{fire:2}}});
  assert.equal((await call("/inject",inj())).body.left,1);
  t.v+=9000;assert.equal((await call("/inject",inj())).body.left,0);
  t.v+=9000;const r=await call("/inject",inj());assert.equal(r.status,409);assert.equal(P(db).inv.fire,0);
});

test("銀行：無限借款→利息累計→還款；欠款不被其他操作覆蓋",async()=>{
  const {call,db,t}=mk();await call("/ensure-market");
  let r=await call("/bank",BK({action:"borrow",amount:50}));assert.equal(r.status,200);assert.equal(r.body.cash,100);assert.equal(r.body.owed,50);
  assert.deepEqual(P(db).loan,{p:50,t:t.v});assert.deepEqual(P(db).hold,{});
  await call("/trade",TR());assert.equal(P(db).loan.p,50);
  t.v+=DAYMS;r=await call("/bank",BK({action:"repay",amount:10}));assert.equal(r.status,200);assert.equal(r.body.owed,42.5);assert.equal(r.body.cash,78);
  r=await call("/bank",BK({action:"repay",all:true}));assert.equal(r.body.owed,0);assert.equal(r.body.cash,35.5);
  assert.equal((await call("/bank",BK({action:"repay",all:true}))).status,409);
  r=await call("/bank",BK({action:"borrow",amount:5000}));assert.equal(r.status,200);assert.equal(r.body.cash,5035.5);   // 想借多少都行
});
test("銀行：金額檢查、現金不足不能還款",async()=>{
  const {call,t}=mk();await call("/ensure-market");
  for(const bad of [0,-5,"abc",2e6,null])assert.equal((await call("/bank",BK({action:"borrow",amount:bad}))).status,400);
  assert.equal((await call("/bank",BK({action:"steal",amount:5}))).status,400);
  await call("/bank",BK({action:"borrow",amount:90}));
  for(let i=0;i<8;i++)await call("/trade",TR({stockId:"steam"}));
  t.v+=3*DAYMS;const r=await call("/bank",BK({action:"repay",all:true}));assert.equal(r.status,409);assert.match(r.body.error.message,/現金不足/);
});

test("黑道：欠款超過 100 並拖過 24 小時 → 資產清空重新開始，全服動態留下紀錄",async()=>{
  const {call,db,t}=mk();await call("/ensure-market");
  await call("/bank",BK({action:"borrow",amount:150}));await call("/trade",TR());                 // 現金 200 → 買 1 股
  t.v+=23*H;assert.equal((await call("/trade",TR())).status,200);                              // 23 小時：還安全
  t.v+=2*H;const r=await call("/trade",TR());                                                  // 25 小時：黑道上門
  assert.equal(r.status,409);assert.equal(r.body.error.code,"mob");assert.match(r.body.error.message,/黑道/);
  assert.deepEqual([P(db).cash,P(db).hold,P(db).loan.p,P(db).bankrupt],[50,{},0,1]);
  const mob=feeds(db).find(x=>x.mob);assert.equal(mob.who,"Botao");assert.ok(mob.owed>150);
  assert.equal((await call("/trade",TR())).status,200);                                        // 重新開始後可以正常玩
  assert.equal(P(db).cash,38);assert.equal(P(db).bankrupt,1);
});
test("黑道：還到 100 以下就解除；之後超過才重新計時；check 與投入也會觸發",async()=>{
  const {call,db,t,state}=mk();await call("/ensure-market");
  await call("/bank",BK({action:"borrow",amount:150}));
  t.v+=20*H;assert.equal((await call("/bank",BK({action:"repay",amount:60}))).status,200);        // 還到約 100 以下
  t.v+=200*H;assert.equal((await call("/bank",BK({action:"check"}))).status,409);                 // 利息把欠款又推過 100，隔很久才發現 → 當然要上門
  const a=mk();await a.call("/ensure-market");await a.call("/bank",BK({action:"borrow",amount:99}));
  a.t.v+=28*H;assert.equal((await a.call("/bank",BK({action:"check"}))).status,200);              // 利息約 5 小時後越線，28 小時時才過 23 小時
  a.t.v+=2*H;const r=await a.call("/bank",BK({action:"check"}));assert.equal(r.status,409);assert.equal(r.body.error.code,"mob");
  const b=mk();await b.call("/ensure-market");await b.call("/bank",BK({action:"borrow",amount:150}));b.t.v+=25*H;
  const j=await b.call("/inject",inj());assert.equal(j.status,409);assert.equal(j.body.error.code,"mob");
});
test("黑道：安全範圍內（≤100）不會被找上，再久也不會",async()=>{
  const {call,t}=mk();await call("/ensure-market");await call("/bank",BK({action:"borrow",amount:100}));
  t.v+=DAYMS/100;assert.equal((await call("/bank",BK({action:"check"}))).status,200);    // 剛借時 = 100，利息一跑就超過；這裡只驗證極短時間內不誤殺
  const s=mk();await s.call("/ensure-market");await s.call("/bank",BK({action:"borrow",amount:60}));s.t.v+=10*DAYMS;
  assert.equal((await s.call("/bank",BK({action:"check"}))).status,200);                  // 60×1.05^10≈97.7，仍在 100 內
});

const DEV="dev@example.com";
const asDev=(o={})=>{const m=mk({devEmails:[DEV],...o});m.state.email=DEV;m.state.emailVerified=true;return m;};
test("開發者：投入元素不需要材料、不扣背包；動態會標示；冷卻仍有效",async()=>{
  const {call,db,state,t}=asDev();await call("/ensure-market");state.noSeed=true;
  const r=await call("/inject",inj());assert.equal(r.status,200);assert.equal(r.body.up,Math.round(.525*100));
  const f=feeds(db).find(x=>x.element);assert.equal(f.dev,true);assert.equal(f.who,"Botao");
  assert.equal(P(db).inv,undefined);
  assert.equal((await call("/inject",inj())).status,429);
  t.v+=9000;assert.equal((await call("/inject",inj())).status,200);
});
test("開發者判斷：信箱未驗證、不在名單、名單為空、大小寫",async()=>{
  const a=asDev();a.state.emailVerified=false;a.state.noSeed=true;await a.call("/ensure-market");
  assert.equal((await a.call("/inject",{stockId:"fire"})).status,409);   // 未驗證 → 當一般玩家，沒有元素不能投
  const b=mk({devEmails:[DEV]});b.state.email="someone@x.com";b.state.emailVerified=true;b.state.noSeed=true;await b.call("/ensure-market");
  assert.equal((await b.call("/inject",{stockId:"fire"})).status,409);
  const c=mk();c.state.email=DEV;c.state.emailVerified=true;c.state.noSeed=true;await c.call("/ensure-market");                      // 沒設定 DEV_EMAILS
  assert.equal((await c.call("/inject",{stockId:"fire"})).status,409);
  const d2=mk({devEmails:[DEV]});d2.state.email=DEV;d2.state.emailVerified=true;
  assert.equal((await d2.call("/whoami")).body.dev,true);assert.equal((await b.call("/whoami")).body.dev,false);assert.equal((await a.call("/whoami")).body.dev,false);
  a.state.provider="anonymous";assert.equal((await a.call("/whoami")).status,401);
});

test("買賣會推動走勢：買進推升、賣出壓低上漲機率；有上限；失敗的交易不影響；不直接改價格",async()=>{
  const {call,db}=mk();await call("/ensure-market");
  await call("/trade",TR());assert.ok(Math.abs(BIAS(db)-.003)<1e-9);assert.equal(MS(db).fire.price,12);assert.equal(MS(db).fire.p.length,1);
  await call("/trade",TR({dir:-1}));assert.ok(Math.abs(BIAS(db))<1e-9);
  assert.equal((await call("/trade",TR({dir:-1}))).status,409);assert.ok(Math.abs(BIAS(db))<1e-9);          // 沒持股賣不出去，不算
  await call("/trade",TR({stockId:"water"}));assert.ok(Math.abs(BIAS(db,"water")-.003)<1e-9);assert.ok(Math.abs(BIAS(db))<1e-9);   // 只影響該檔
  await call("/bank",BK({action:"borrow",amount:1000}));
  for(let i=0;i<5;i++)await call("/trade",TR({shares:80}));assert.equal(BIAS(db),.15);                  // 買再多也只到 65%
  // 買賣沒有套利：連續買進再賣出，現金只會因為價格不變而回到原點（沒有憑空賺到的價差）
  const {call:c2,db:d2}=mk();await c2("/ensure-market");const cash0=50;await c2("/trade",TR());await c2("/trade",TR({dir:-1}));assert.equal(d2.m.get("players/g1").data.cash,cash0);
});
test("多人同時買賣會疊加但被上限擋住，且彼此不互相覆蓋",async()=>{
  const A=mk(),db=A.db;await A.call("/ensure-market");
  for(const [uid,name] of [["g1","甲"],["g2","乙"],["g3","丙"]]){A.state.uid=uid;A.state.name=name;await A.call("/trade",TR());}
  assert.ok(Math.abs(BIAS(db)-.009)<1e-9);assert.equal(["g1","g2","g3"].every(u=>db.m.get("players/"+u).data.hold.fire===1),true);
});

test("投入的機率提升每 5 分鐘降 10%（回到 50%），且與排程間隔無關",async()=>{
  const M=300000;
  const up=mk();await up.call("/ensure-market");await up.call("/inject",inj({stockId:"steam"}));
  assert.ok(Math.abs(EFF(up,"steam")-.05)<1e-9);
  const seen=[];
  for(let i=1;i<=40;i++){up.t.v+=M;await tick(up.d);seen.push(EFF(up,"steam"));}
  assert.ok(Math.abs(seen[0]-.045)<1e-9);                                                       // 5 分鐘後剩 90%
  assert.ok(Math.abs(seen[9]-.05*Math.pow(.9,10))<1e-9);                                        // 50 分鐘後
  assert.equal(seen[39],0);                                                                     // 久了回到 50%
  // 每 2 分鐘一次與每 10 分鐘一次，結果相同
  const a=mk(),b=mk();
  for(const x of [a,b]){await x.call("/ensure-market");await x.call("/inject",inj({stockId:"steam"}));}
  for(let i=0;i<5;i++){a.t.v+=120000;await tick(a.d);}b.t.v+=600000;await tick(b.d);
  assert.ok(Math.abs(EFF(a,"steam")-EFF(b,"steam"))<1e-9);assert.ok(Math.abs(EFF(a,"steam")-.05*.81)<1e-9);
  // 買賣疊加在「已衰減」的值上
  b.t.v+=M;await b.call("/trade",TR({stockId:"steam"}));assert.ok(Math.abs(BIAS(b.db,"steam")-(.05*.81*.9+.003))<1e-9);
});

test("存款：活存/定存的存入、領出、利息、到期轉換、提前解約；不被其他操作覆蓋",async()=>{
  const {call,db,t}=mk();await call("/ensure-market");
  let r=await call("/bank",BK({action:"dem_in",amount:30}));assert.equal(r.status,200);assert.equal(r.body.cash,20);assert.equal(r.body.deposits,30);
  r=await call("/bank",BK({action:"td_in",amount:20}));assert.equal(r.status,200);assert.equal(r.body.cash,0);assert.equal(r.body.deposits,50);
  const at=P(db).tds[0].t;assert.deepEqual(P(db).dem.a,30);assert.equal(P(db).tds.length,1);
  await call("/trade",TR({dir:1}));                                                                   // 現金 0 買不起 → 失敗，但不影響存款
  assert.equal(P(db).tds.length,1);
  t.v+=DAYMS;r=await call("/bank",BK({action:"dem_out",amount:10}));assert.equal(r.status,200);
  assert.ok(Math.abs(r.body.cash-10)<1e-9);assert.ok(Math.abs(P(db).dem.a-(30*1.004-10))<1e-3);
  assert.equal((await call("/bank",BK({action:"td_break",at:at+1}))).status,409);                    // 找不到
  r=await call("/bank",BK({action:"td_break",at}));assert.equal(r.status,200);assert.equal(r.body.cash,30);assert.equal(P(db).tds.length,0);   // 只退本金 20
  await call("/bank",BK({action:"td_in",amount:30}));const at2=P(db).tds[0].t;
  t.v+=4*DAYMS;r=await call("/bank",BK({action:"check"}));assert.equal(r.status,200);                 // check 不結算
  r=await call("/bank",BK({action:"dem_out",all:true}));assert.equal(r.status,200);
  assert.ok(Math.abs(r.body.cash-((30*1.004-10)*1.004**4+30*1.012**3*1.004))<0.02,String(r.body.cash));   // 活存餘額＋到期的定存（再算 1 天活存）
  assert.equal(P(db).tds.length,0);assert.equal(P(db).dem.a,0);
  assert.equal((await call("/bank",BK({action:"td_break",at:at2}))).status,409);                      // 已到期轉入活存，不能再解約
});
test("存款：錯誤處理與限制",async()=>{
  const {call}=mk();await call("/ensure-market");
  assert.equal((await call("/bank",BK({action:"dem_in",amount:60}))).status,409);                    // 現金只有 50
  assert.equal((await call("/bank",BK({action:"dem_out",amount:5}))).status,409);                    // 沒有餘額
  assert.equal((await call("/bank",BK({action:"td_in",amount:0.001}))).status,400);                  // 金額檢查（四捨五入後 <0.01 不合法）
  assert.equal((await call("/bank",BK({action:"td_in",amount:0.5}))).status,409);                    // 定存最少 1
  assert.equal((await call("/bank",BK({action:"td_break"}))).status,400);
  for(let i=0;i<20;i++)assert.equal((await call("/bank",BK({action:"td_in",amount:1}))).status,200,String(i));
  assert.equal((await call("/bank",BK({action:"td_in",amount:1}))).status,409);                      // 定存最多 20 筆（這裡現金只剩 30）
});
test("黑道：連存款也一併被搶光",async()=>{
  const {call,db,t}=mk();await call("/ensure-market");
  await call("/bank",BK({action:"borrow",amount:300}));await call("/bank",BK({action:"dem_in",amount:100}));await call("/bank",BK({action:"td_in",amount:100}));
  assert.equal(P(db).tds.length,1);
  t.v+=25*H;const r=await call("/bank",BK({action:"dem_out",all:true}));assert.equal(r.status,409);assert.equal(r.body.error.code,"mob");
  assert.deepEqual([P(db).cash,P(db).dem.a,P(db).tds.length,P(db).loan.p],[50,0,0,0]);
});

// ================= 財經新聞 =================
const PUB=(x={})=>({action:"publish",title:"央行宣布降息",body:"市場看好\n火系股票受惠",durationMin:60,effects:{fire:10},cash:0,...x});
const NEWS=db=>[...db.m].filter(([k])=>k.startsWith("news/")).map(([k,v])=>({id:k.slice(5),...v.data}));
test("財經新聞：只有開發者能發布；活動寫進新聞與行情",async()=>{
  const {call,db,t,state}=asDev();await call("/ensure-market");
  const r=await call("/news",PUB({cash:100}));assert.equal(r.status,200);assert.equal(r.body.endsAt,t.v+60*60000);
  const n=NEWS(db)[0];assert.deepEqual([n.title,n.body,n.durationMin,n.cash,n.by,n.endsAt],["央行宣布降息","市場看好\n火系股票受惠",60,100,"Botao",t.v+3600000]);assert.equal(n.at,"TS");assert.equal("effects" in n,false);
  const ev=OD(db).events;assert.equal(ev.length,1);assert.deepEqual([ev[0].id,ev[0].until,ev[0].shift],[n.id,t.v+3600000,{fire:.1}]);
  const m=mk({devEmails:[DEV]});await m.call("/ensure-market");                                                    // 一般玩家
  assert.equal((await m.call("/news",PUB())).status,403);assert.equal((await m.call("/news",{action:"end",id:n.id})).status,403);
  const u=asDev();u.state.emailVerified=false;await u.call("/ensure-market");assert.equal((await u.call("/news",PUB())).status,403);   // 信箱未驗證
  state.provider="anonymous";assert.equal((await call("/news",PUB())).status,401);
  assert.equal((await asDev().call("/news",{action:"zzz"})).status,400);
});
test("財經新聞：輸入檢查",async()=>{
  const {call,db}=asDev();await call("/ensure-market");
  const bad=async x=>(await call("/news",PUB(x))).status;
  assert.equal(await bad({title:""}),400);assert.equal(await bad({title:"x".repeat(41)}),400);assert.equal(await bad({title:"換\n行"}),400);assert.equal(await bad({title:5}),400);
  assert.equal(await bad({body:"x".repeat(601)}),400);assert.equal(await bad({body:"控制\u0001字元"}),400);
  for(const m of [0,0.5,43201,"abc",null,-5])assert.equal(await bad({durationMin:m}),400,String(m));
  for(const e of [{fire:0},{fire:41},{fire:-41},{fire:1.5},{fire:"10"},{FIRE:10},{nosuch:10},{"f":5},[1,2]])assert.equal(await bad({effects:e}),400,JSON.stringify(e));
  for(const c of [-1,1e6+1,"abc"])assert.equal(await bad({cash:c}),400,String(c));
  assert.equal(await bad({effects:{fire:-40,water:40},cash:1e6}),200);assert.equal(await bad({effects:{},body:""}),200);               // 邊界值與純公告
  assert.equal(await bad({durationMin:1}),200);assert.equal(await bad({durationMin:43200}),200);
  assert.equal(OD(db).events.length,3);                                                                         // 純公告不佔用行情的活動名額
  for(let i=0;i<17;i++)assert.equal(await bad({effects:{wind:1}}),200);assert.equal(await bad({effects:{wind:1}}),400);               // 同時最多 20 個有影響的活動
  assert.equal(await bad({effects:{}}),200);
});
test("財經新聞：活動期間改變上漲基準機率，結束後自動恢復；排程會清掉過期活動",async()=>{
  const A=asDev({rand:()=>.55});await A.call("/ensure-market");
  const up=()=>MS(A.db).fire.price;
  await A.call("/news",PUB({effects:{fire:10,water:-10},durationMin:10}));
  A.t.v+=120000;await tick(A.d);                                                // 活動中：火 60%（0.55 會漲）、水 40%（0.55 會跌）、其他 50%（0.55 會跌）
  assert.ok(up()>12);assert.ok(MS(A.db).water.price<10);assert.ok(MS(A.db).earth.price<8);
  A.t.v+=10*60000;await tick(A.d);                                              // 活動已結束：火回到 50%（0.55 會跌），且活動被清除
  assert.ok(MS(A.db).fire.price<up()+1e-9&&OD(A.db).events.length===0);
  const p1=up();A.t.v+=120000;await tick(A.d);assert.ok(up()<p1);
});
test("財經新聞：多個活動疊加；投入元素回報的上漲機率包含活動",async()=>{
  const A=asDev({rand:()=>.5});await A.call("/ensure-market");
  await A.call("/news",PUB({effects:{fire:10}}));await A.call("/news",PUB({effects:{fire:5},title:"另一則"}));
  const r=await A.call("/inject",inj());assert.equal(r.status,200);assert.equal(r.body.up,Math.round((.5+.15+.025)*100));   // 活動 +15、基礎元素 +2.5
  assert.ok(Math.abs(BIAS(A.db)-.025)<1e-9);                                                                       // 活動不會混進玩家的偏移
});
test("財經新聞：開發者可以提前結束活動",async()=>{
  const {call,db,t}=asDev();await call("/ensure-market");
  const {body:{id}}=await call("/news",PUB({cash:50}));t.v+=60000;
  assert.equal((await call("/news",{action:"end",id})).status,200);
  assert.equal(NEWS(db)[0].endsAt,t.v);assert.equal(OD(db).events.length,0);
  assert.equal((await call("/news",{action:"claim",id})).status,409);                                       // 結束後不能再領
  assert.equal((await call("/news",{action:"end",id:"00000000-0000-0000-0000-000000000000"})).status,404);
  assert.equal((await call("/news",{action:"end",id:"../x"})).status,400);
});
test("普發現金：每位玩家在活動期間領一次，不需要 IA",async()=>{
  const A=asDev();await A.call("/ensure-market");A.state.iaDown=true;
  const {body:{id}}=await A.call("/news",PUB({effects:{},cash:100,durationMin:30}));
  const U=(uid)=>{A.state.uid=uid;A.state.email="player@example.com";};
  U("g7");let r=await A.call("/news",{action:"claim",id});assert.equal(r.status,200);assert.equal(r.body.amount,100);
  assert.deepEqual([A.db.m.get("players/g7").data.cash,A.db.m.get("players/g7").data.name,Object.keys(A.db.m.get("players/g7").data.claims)],[150,"Botao",[id]]);   // 新玩家自動建檔
  r=await A.call("/news",{action:"claim",id});assert.equal(r.status,409);assert.match(r.body.error.message,/已經領過/);
  U("g8");assert.equal((await A.call("/news",{action:"claim",id})).status,200);assert.equal(A.db.m.get("players/g8").data.cash,150);          // 別人各領各的
  A.t.v+=31*60000;U("g9");r=await A.call("/news",{action:"claim",id});assert.equal(r.status,409);assert.match(r.body.error.message,/已經結束/);   // 過期
  A.state.email=DEV;const none=await A.call("/news",PUB({effects:{},cash:0}));assert.equal(none.status,200);U("g7");assert.equal((await A.call("/news",{action:"claim",id:none.body.id})).status,409);   // 沒現金的活動
  assert.equal((await A.call("/news",{action:"claim",id:"nope"})).status,400);
  assert.equal((await A.call("/news",{action:"claim",id:"11111111-1111-1111-1111-111111111111"})).status,409);
  A.state.provider="anonymous";assert.equal((await A.call("/news",{action:"claim",id})).status,401);
});
test("普發現金：領取紀錄只留最近 100 筆；被黑道搶光後現金歸零但仍不能重領",async()=>{
  const A=asDev();await A.call("/ensure-market");
  const ids=[];for(let i=0;i<3;i++)ids.push((await A.call("/news",PUB({effects:{},cash:10,durationMin:43200,title:"活動"+i}))).body.id);
  A.state.email="player@example.com";
  for(const id of ids)assert.equal((await A.call("/news",{action:"claim",id})).status,200);
  assert.equal(A.db.m.get("players/g1").data.cash,80);
  await A.call("/bank",{action:"borrow",amount:300});A.t.v+=25*H;
  assert.equal((await A.call("/news",{action:"claim",id:ids[0]})).status,409);                              // 先觸發黑道（欠款拖過一天）
  assert.equal(A.db.m.get("players/g1").data.cash,50);
  assert.equal((await A.call("/news",{action:"claim",id:ids[0]})).status,409);                              // 已領過的不能重領
});

// ================= 機率只有開發者看得到 =================
const SECRET_KEYS=new Set(["bias","biasAt","events","shift","effects","up"]);
const leaks=(o,path="")=>Object.entries(o||{}).flatMap(([k,v])=>[...(SECRET_KEYS.has(k)?[path+"/"+k]:[]),...(v&&typeof v==="object"&&!Array.isArray(v)?leaks(v,path+"/"+k):[])]);
test("機率只有開發者看得到：公開文件（行情/新聞/動態/玩家）完全不含機率資訊",async()=>{
  const A=asDev();await A.call("/ensure-market");
  await A.call("/news",PUB({effects:{fire:10,water:-5},cash:20}));await A.call("/inject",inj());await A.call("/trade",TR());await A.call("/trade",TR({stockId:"water"}));
  A.t.v+=120000;await tick(A.d);await A.call("/inject",inj({itemName:"雷"}));
  const pub=[...A.db.m].filter(([k])=>!k.startsWith("secret/")&&!k.startsWith("links/")&&!k.startsWith("iaLinks/"));
  assert.ok(pub.length>=5);
  for(const [k,v] of pub)assert.deepEqual(leaks(v.data),[],k);
  assert.ok(Object.keys(OD(A.db).bias).length>=2&&OD(A.db).events.length===1);                                    // 機率確實存在，只是在私密文件
});
test("/odds：只有開發者能查；一般玩家、未驗證信箱、匿名都不行",async()=>{
  const D=asDev();await D.call("/ensure-market");await D.call("/news",PUB({effects:{fire:10}}));await D.call("/inject",inj());
  const r=await D.call("/odds");assert.equal(r.status,200);assert.equal(r.body.now,D.t.v);assert.ok(Math.abs(r.body.bias.fire.v-.025)<1e-9);
  assert.equal(r.body.events.length,1);assert.deepEqual(r.body.events[0].shift,{fire:.1});
  D.t.v+=3700000;assert.equal((await D.call("/odds")).body.events.length,0);                                       // 過期活動不回傳
  const P=mk({devEmails:[DEV]});await P.call("/ensure-market");assert.equal((await P.call("/odds")).status,403);
  const U=asDev();U.state.emailVerified=false;await U.call("/ensure-market");assert.equal((await U.call("/odds")).status,403);
  const N=asDev();await N.call("/ensure-market");N.state.provider="anonymous";assert.equal((await N.call("/odds")).status,401);
});
test("投入結果：只有開發者會收到上漲機率",async()=>{
  const D=asDev();await D.call("/ensure-market");
  const r=await D.call("/inject",inj());assert.equal(r.body.up,53);
  const P=mk();await P.call("/ensure-market");assert.equal("up" in (await P.call("/inject",inj())).body,false);
});
test("純資訊活動（例如前情公告）：沒有影響、沒有現金，只是一則新聞",async()=>{
  const D=asDev();await D.call("/ensure-market");
  const r=await D.call("/news",{action:"publish",title:"前情提要",body:"很久很久以前…",durationMin:1440});assert.equal(r.status,200);   // 不帶 effects / cash
  const n=NEWS(D.db)[0];assert.deepEqual([n.title,n.cash,"effects" in n],["前情提要",0,false]);
  assert.equal(OD(D.db).events.length,0);                                                                          // 不影響行情，也不佔活動名額
  D.state.email="player@example.com";assert.equal((await D.call("/news",{action:"claim",id:n.id})).status,409);   // 沒有現金可領
});
test("舊資料搬家：機率偏移/活動從公開行情搬進私密文件，並把公開欄位清掉",async()=>{
  const A=mk();await A.call("/ensure-market");
  const m=A.db.m.get("market/state");                                                                              // 模擬舊版資料
  m.data.stocks.fire={...m.data.stocks.fire,bias:.1,biasAt:A.t.v};m.data.events=[{id:"e1",until:A.t.v+9e6,shift:{fire:.2}}];A.db.m.delete("secret/odds");
  await tick(A.d);
  assert.deepEqual(leaks(A.db.m.get("market/state").data),[]);
  assert.ok(Math.abs(OD(A.db).bias.fire.v-.1)<1e-9);assert.equal(OD(A.db).events[0].id,"e1");assert.equal(MS(A.db).fire.t.length,2);
});

// ================= 自動財經新聞（台北 10/14/18/22 點） =================
import {generateAutoNews} from "../src/app.js";
import {autoNews as aiAutoNews} from "../src/ia.js";
const TPE=(h,m=0)=>Date.UTC(2027,0,15,h-8,m);   // 台北時間 2027-01-15 h:m
const newsDocs=db=>[...db.m].filter(([k])=>k.startsWith("news/")).map(([k,v])=>({id:k.slice(5),...v.data}));
function mkNews(hour,fn){
  const x=mk();x.t.v=TPE(hour,0);x.calls=0;
  x.d.autoNews=async(stocks,slot,date)=>{x.calls++;x.last={stocks,slot,date};return fn?fn():{title:"賢者之塔宣布火焰免稅",body:"【賢者之塔連線報導】"+"練金村主人 Funtuan 今日宣布".repeat(6),effects:{fire:30,water:-12}};};
  return x;
}
test("自動新聞：只在 10/14/18/22 點發布，每時段一則，影響寫進私密文件、公開新聞不含影響",async()=>{
  const x=mkNews(10);await x.call("/ensure-market");
  const r=await generateAutoNews(x.d);assert.equal(r.published,true);
  assert.equal((await generateAutoNews(x.d)).skipped,true);assert.equal(x.calls,1);          // 同一時段不重複
  const n=newsDocs(x.db);assert.equal(n.length,1);assert.equal(n[0].by,"練金村財經快報");assert.equal(n[0].cash,0);
  assert.ok(!("effects" in n[0])&&!("shift" in n[0]));
  assert.deepEqual(OD(x.db).events.map(e=>e.shift),[{fire:.3,water:-.12}]);
  assert.equal(x.last.slot,10);assert.equal(x.last.date,"2027-01-15");
  x.t.v=TPE(10,59);await generateAutoNews(x.d);assert.equal(x.calls,1);
  x.t.v=TPE(11,0);await generateAutoNews(x.d);assert.equal(x.calls,1);                         // 非整點時段不發
  x.t.v=TPE(14,0);assert.equal((await generateAutoNews(x.d)).published,true);
  x.t.v=TPE(18,5);assert.equal((await generateAutoNews(x.d)).published,true);
  x.t.v=TPE(22,30);assert.equal((await generateAutoNews(x.d)).published,true);
  assert.equal(newsDocs(x.db).length,4);
});
test("自動新聞：其他時段不呼叫 AI；AI 失敗時可在同時段重試；沒設 Key 則略過",async()=>{
  const x=mkNews(9);await x.call("/ensure-market");assert.equal((await generateAutoNews(x.d)).skipped,true);assert.equal(x.calls,0);
  const y=mk();y.t.v=TPE(10);await y.call("/ensure-market");assert.equal((await generateAutoNews(y.d)).skipped,true);   // 沒有 autoNews
  let fail=true;const z=mkNews(10,()=>{if(fail)throw new Error("Gemini 429");return {title:"標題標題",body:"【練金村連線報導】"+"內文".repeat(40),effects:{}};});
  await z.call("/ensure-market");await assert.rejects(generateAutoNews(z.d),/429/);
  z.t.v=TPE(10,0)+30000;const b=await generateAutoNews(z.d);assert.ok(b.skipped||b.busy);assert.equal(z.calls,1);   // 鎖 50 秒內不重打 AI
  z.t.v=TPE(10,2);fail=false;assert.equal((await generateAutoNews(z.d)).published,true);
  assert.equal(newsDocs(z.db).length,1);
});
test("自動新聞：AI 輸出驗證（股票代號、±30 上限、最多 2 檔、格式錯誤丟棄）",async()=>{
  const mkF=o=>async()=>({ok:true,json:async()=>({candidates:[{content:{parts:[{text:JSON.stringify(o)}]}}]})});
  const stocks=[{id:"fire",name:"火"},{id:"water",name:"水"},{id:"earth",name:"土"}],body="【練金村連線報導】"+"內文".repeat(40);
  const r=await aiAutoNews(mkF({title:"火之稅改革震撼市場",body,effects:{fire:99,water:-45,earth:1,fake:2,wind:0}}),"k".repeat(12),stocks,10,"2027-01-15");
  assert.deepEqual(r.effects,{fire:30,water:-30});
  await assert.rejects(aiAutoNews(mkF({title:"短",body,effects:{}}),"k".repeat(12),stocks,10,"d"),/invalid/);
  await assert.rejects(aiAutoNews(mkF({title:"標題標題標題",body:"太短",effects:{}}),"k".repeat(12),stocks,10,"d"),/invalid/);
});

// ================= 借貸保釋 =================
test("保釋：被黑道關押時可借保釋貸款出獄（現金不變、欠款增加、之後可正常行動）；沒在服刑不能保釋",async()=>{
  const {call,db,t}=mk();await call("/ensure-market");
  assert.equal((await call("/bank",BK({action:"bail"}))).status,409);                            // 還沒有玩家資料／沒在服刑
  await call("/bank",BK({action:"borrow",amount:150}));t.v+=25*H;
  assert.equal((await call("/trade",TR())).body.error.code,"mob");                                 // 黑道上門：現金 50、關押 24 小時
  assert.equal((await call("/trade",TR())).status,403);                                            // 服刑中不能行動
  assert.equal((await call("/bank",BK({action:"repay",amount:1}))).status,403);                    // 服刑中其他銀行動作仍被擋
  const r=await call("/bank",BK({action:"bail"}));assert.equal(r.status,200);assert.equal(r.body.bail,80);assert.equal(r.body.owed,80);
  assert.deepEqual([P(db).cash,P(db).jailUntil,P(db).loan.p,P(db).bails],[50,0,80,1]);
  assert.equal((await call("/trade",TR())).status,200);                                            // 出獄後可以玩
  assert.equal((await call("/bank",BK({action:"bail"}))).status,409);                              // 已經自由，不能再保釋
});
test("保釋：貸款疊加在既有欠款上並照利率滾利；欠款過高又拖過一天黑道仍會再來",async()=>{
  const A=mk();await A.call("/ensure-market");
  await A.call("/bank",BK({action:"borrow",amount:50}));
  A.db.m.get("players/g1").data.jailUntil=A.t.v+H;                                                // 模擬被關（例如搶劫失敗）
  const r=await A.call("/bank",BK({action:"bail"}));assert.equal(r.status,200);assert.ok(Math.abs(r.body.owed-130)<.01);
  assert.equal(P(A.db).jailUntil,0);
  A.t.v+=25*H;assert.equal((await A.call("/bank",BK({action:"check"}))).body.error.code,"mob");   // 欠款 >100 並拖過 24 小時
  assert.ok(P(A.db).jailUntil>A.t.v);
});

// ================= 練金大富翁（52 格） =================
import * as B from "../../public/board.js";
const seed=(db,uid,o={})=>db.m.set(`players/${uid}`,{v:"s"+uid,data:{cash:1000,hold:{},name:uid==="g1"?"Botao":"路人"+uid,...o}});
const seq=(...xs)=>{let i=0;return()=>xs[Math.min(i++,xs.length-1)];};          // 依序回傳指定亂數
const dice=(a,b)=>[(a-1)/6+.01,(b-1)/6+.01];                                      // 讓兩顆骰子擲出 a、b
const MP=db=>db.m.get("monopoly/state").data;
const MO=async x=>{if(!x.db.m.has("market/state"))await x.call("/ensure-market");return x.call("/monopoly",{action:"roll"});};
const firstOf=type=>B.BOARD.findIndex(t=>t.type===type);
test("大富翁：棋盤 52 格，32 塊地產、4 座煉爐，卡片目的地存在",()=>{
  assert.equal(B.BOARD.length,52);
  const c={};B.BOARD.forEach(t=>c[t.type]=(c[t.type]||0)+1);
  assert.deepEqual([c.prop,c.rail,c.chance,c.fate,c.tax,c.start,c.jail,c.park,c.gojail],[32,4,5,5,2,1,1,1,1]);
  for(const k of [...B.CHANCE_CARDS,...B.FATE_CARDS])if(k.e.k==="goto")assert.ok(k.e.v>=0&&k.e.v<52);
  assert.equal(B.BOARD[B.JAIL_IDX].type,"jail");
});
test("大富翁：擲骰收 100 元、移動並寫進公開棋盤；現金不足與太快都會被擋",async()=>{
  const x=mk({rand:seq(...dice(2,3))});seed(x.db,"g1");
  const r=await MO(x);assert.equal(r.status,200);assert.deepEqual([r.body.dice,r.body.from,r.body.to,r.body.cost],[[2,3],0,5,100]);
  assert.equal(P(x.db).cash,900);assert.equal(MP(x.db).pos.g1.p,5);assert.equal(MP(x.db).pos.g1.n,"Botao");
  assert.equal((await MO(x)).status,429);                                  // 2 秒內不能連擲
  x.t.v+=3000;P(x.db).cash=50;x.db.m.get("players/g1").data.cash=50;
  assert.equal((await MO(x)).status,409);                                  // 現金不足 100
  assert.equal((await x.call("/monopoly",{action:"dance"})).status,400);
});
test("大富翁：買地、不可重複買；租金轉給主人；湊齊同色租金加倍；升級加租",async()=>{
  const x=mk({rand:seq(...dice(2,2),...dice(2,2),...dice(2,2),...dice(2,2))});seed(x.db,"g1");seed(x.db,"g2");
  await x.call("/ensure-market");const t=4;assert.equal(B.BOARD[t].type,"prop");assert.equal((await x.call("/monopoly",{action:"buy"})).status,409);   // 站在起點不能買
  await MO(x);                                                              // g1 → 4
  const b=await x.call("/monopoly",{action:"buy"});assert.equal(b.status,200);assert.equal(P(x.db).cash,1000-100-B.BOARD[t].price);
  assert.deepEqual(MP(x.db).owners[t],{u:"g1",n:"Botao",lv:0});
  x.state.uid="g2";x.state.name="路人";x.t.v+=3000;
  assert.equal((await x.call("/monopoly",{action:"buy"})).status,409);       // g2 還在起點
  const r=await MO(x);assert.equal(r.body.to,t);assert.equal(r.body.paidTo,"Botao");   // g2 落在 g1 的地上
  const rent=B.BOARD[t].rent;
  assert.equal(x.db.m.get("players/g2").data.cash,1000-100-rent);
  assert.equal(P(x.db).cash,1000-100-B.BOARD[t].price+rent);
  assert.equal((await x.call("/monopoly",{action:"buy"})).status,409);       // 已被買走
  x.state.uid="g1";
  const up=await x.call("/monopoly",{action:"upgrade",tile:t});assert.equal(up.status,200);assert.equal(MP(x.db).owners[t].lv,1);
  assert.equal(B.rentOf(t,MP(x.db).owners),rent*3);
  const o2={};for(const i of B.groupTiles(B.BOARD[t].group))o2[i]={u:"g1",lv:0};
  assert.equal(B.rentOf(t,o2),rent*2);                                       // 湊齊同色 ×2
  assert.equal((await x.call("/monopoly",{action:"upgrade",tile:0})).status,400);
  x.state.uid="g2";assert.equal((await x.call("/monopoly",{action:"upgrade",tile:t})).status,409);   // 不是自己的
});
test("大富翁：經過起點領 500；稅務所與押送入獄；現金不夠時只付剩下的",async()=>{
  const x=mk({rand:seq(...dice(5,5),...dice(1,2),...dice(3,3))});seed(x.db,"g1");
  x.db.m.set("monopoly/state",{v:"m0",data:{owners:{},pos:{g1:{p:48,n:"Botao",at:0}},log:[]}});
  const r=await MO(x);assert.equal(r.body.to,6);assert.equal(r.body.events[0],"經過起點，領薪水 500 元");assert.equal(P(x.db).cash,1000-100+500);
  const tax=B.BOARD.findIndex(t=>t.type==="tax");
  x.db.m.get("monopoly/state").data.pos.g1.p=tax-3;x.t.v+=3000;x.db.m.get("players/g1").data.cash=250;
  const r2=await MO(x);assert.equal(r2.body.to,tax);assert.equal(P(x.db).cash,150-Math.min(150,B.TAX));
  const gj=firstOf("gojail");x.db.m.get("monopoly/state").data.pos.g1.p=gj-6;x.t.v+=3000;x.db.m.get("players/g1").data.cash=1000;
  const r3=await MO(x);assert.equal(r3.body.to,B.JAIL_IDX);assert.equal(P(x.db).cash,1000-100-B.JAIL_FINE);
  assert.ok(!(P(x.db).jailUntil>0));                                         // 只是移到探監格，不會真的被關 24 小時
});
test("大富翁：機會卡（現金、免費擲骰、移動）與免費擲骰不收費",async()=>{
  const ch=B.BOARD.findIndex(t=>t.type==="chance"),pick=i=>(i+.5)/B.CHANCE_CARDS.length;
  const iFree=B.CHANCE_CARDS.findIndex(c=>c.e.k==="free"&&c.e.v===2),iCash=B.CHANCE_CARDS.findIndex(c=>c.e.k==="cash"&&c.e.v===300);
  const x=mk({rand:seq(...dice(1,2),pick(iFree),...dice(1,2),pick(iCash))});seed(x.db,"g1");
  assert.equal(ch,3);
  const r=await MO(x);assert.equal(r.body.to,3);assert.equal(r.body.card.kind,"機會");assert.equal(P(x.db).mfree,2);assert.equal(P(x.db).cash,900);
  x.db.m.get("monopoly/state").data.pos.g1.p=0;x.t.v+=3000;
  const r2=await MO(x);assert.equal(r2.body.cost,0);assert.equal(r2.body.free,true);assert.equal(P(x.db).cash,900+300);assert.equal(P(x.db).mfree,1);
});
test("大富翁：地產算進排行榜；公開棋盤文件不含任何機率資料；服刑中不能擲骰",async()=>{
  const x=mk({rand:seq(...dice(2,2))});seed(x.db,"g1");
  await MO(x);await x.call("/monopoly",{action:"buy"});
  const lb=(await x.call("/leaderboard",{})).body.rows.find(r=>r.isMe);
  assert.equal(lb.value,1000-100);                                           // 買地不吃虧：現金少了，地產價值補回來
  assert.ok(!/odds|bias|prob|shift/i.test(JSON.stringify(MP(x.db))));
  x.db.m.get("players/g1").data.jailUntil=x.t.v+H;x.t.v+=3000;
  assert.equal((await MO(x)).status,403);
});

// ================= 玩家交易權狀 =================
const MA=(x,body)=>x.call("/monopoly",body);
async function twoPlayers(){
  const x=mk({rand:seq(...dice(2,2))});seed(x.db,"g1");seed(x.db,"g2");await x.call("/ensure-market");
  await MO(x);await MA(x,{action:"buy"});                                            // g1 買下第 4 格
  await MA(x,{action:"upgrade",tile:4});                                             // 升到 1 級
  return x;
}
test("交易：賣家掛牌、買家接受 → 權狀（含等級）易主、現金與地產價值同步轉移",async()=>{
  const x=await twoPlayers(),price=B.BOARD[4].price;
  const l=await MA(x,{action:"list",tile:4,price:900});assert.equal(l.status,200);
  assert.equal((await MA(x,{action:"list",tile:4,price:0})).status,400);
  assert.equal((await MA(x,{action:"list",tile:5,price:100})).status,409);               // 第 5 格沒人持有
  const cash1=P(x.db).cash;
  x.state.uid="g2";x.state.name="路人";
  assert.equal((await MA(x,{action:"accept",offerId:"nope"})).status,404);
  const a=await MA(x,{action:"accept",offerId:l.body.offerId});assert.equal(a.status,200);assert.equal(a.body.role,"buyer");
  assert.deepEqual(MP(x.db).owners[4],{u:"g2",n:"路人g2",lv:1});
  assert.equal(x.db.m.get("players/g2").data.cash,1000-900);assert.equal(P(x.db).cash,cash1+900);
  assert.equal(x.db.m.get("players/g2").data.mprop,B.propertyValue(MP(x.db).owners,"g2"));
  assert.equal(P(x.db).mprop,0);assert.equal(Object.keys(MP(x.db).offers).length,0);
  assert.equal((await MA(x,{action:"accept",offerId:l.body.offerId})).status,404);       // 同一張不能重複成交
  assert.ok(price>0);
});
test("交易：買家出價、持有人接受；持有人也可拒絕；不能和自己交易；現金不夠不能成交",async()=>{
  const x=await twoPlayers();
  x.state.uid="g2";
  assert.equal((await MA(x,{action:"bid",tile:4,price:2e6})).status,400);
  const rich=await MA(x,{action:"bid",tile:4,price:5000});assert.equal(rich.status,409);   // 出價就要有錢（1000）
  const b=await MA(x,{action:"bid",tile:4,price:700});assert.equal(b.status,200);
  assert.equal((await MA(x,{action:"accept",offerId:b.body.offerId})).status,409);        // 自己的出價自己不能接受
  x.state.uid="g1";
  const cash1=P(x.db).cash;
  const r=await MA(x,{action:"accept",offerId:b.body.offerId});assert.equal(r.status,200);assert.equal(r.body.role,"seller");
  assert.equal(MP(x.db).owners[4].u,"g2");assert.equal(P(x.db).cash,cash1+700);assert.equal(x.db.m.get("players/g2").data.cash,300);
  // 拒絕：g1 對 g2 的地出價，g2 取消（拒絕）
  const b2=await MA(x,{action:"bid",tile:4,price:100});assert.equal(b2.status,200);
  x.state.uid="g2";assert.equal((await MA(x,{action:"cancel",offerId:b2.body.offerId})).status,200);
  assert.equal(Object.keys(MP(x.db).offers).length,0);
  // 現金不夠：g2 掛牌賣 5000，g1 現金不足
  const l=await MA(x,{action:"list",tile:4,price:5000});x.state.uid="g1";
  assert.equal((await MA(x,{action:"accept",offerId:l.body.offerId})).status,409);assert.equal(MP(x.db).owners[4].u,"g2");
});
test("交易：權狀已易主的舊掛牌作廢；別人不能取消你的掛牌；掛牌過期自動清除；排行榜地產價值跟著走",async()=>{
  const x=await twoPlayers();
  const l=await MA(x,{action:"list",tile:4,price:300});
  const b=await MA(x,{action:"list",tile:4,price:310});                                   // 同一格再掛 → 只留最新一張
  assert.equal(Object.keys(MP(x.db).offers).length,1);
  x.state.uid="g2";assert.equal((await MA(x,{action:"cancel",offerId:b.body.offerId})).status,403);
  // 偷偷換主：直接改棋盤資料模擬已易主
  x.db.m.get("monopoly/state").data.owners[4].u="g3";
  assert.equal((await MA(x,{action:"accept",offerId:b.body.offerId})).status,409);
  assert.equal(Object.keys(MP(x.db).offers).length,0);
  x.db.m.get("monopoly/state").data.owners[4].u="g1";
  const l2=await MA(x,{action:"accept",offerId:l.body.offerId});assert.equal(l2.status,404);
  x.state.uid="g1";const l3=await MA(x,{action:"list",tile:4,price:300});assert.equal(l3.status,200);
  x.t.v+=49*H;x.state.uid="g2";assert.equal((await MA(x,{action:"accept",offerId:l3.body.offerId})).status,404);   // 超過 48 小時
});

// ================= 自訂買賣股數 =================
test("買賣：可自訂 1～100000 的整數股數；0、小數、過大、非數字都被拒絕；買賣壓力仍受 ±15 上限",async()=>{
  const x=mk();await x.call("/ensure-market");seed(x.db,"g1",{cash:1e6});
  const price=x.db.m.get("market/state").data.stocks.fire.price;
  const T=(shares,dir=1)=>x.call("/trade",{stockId:"fire",dir,shares});
  const r=await T(37);assert.equal(r.status,200);assert.equal(r.body.hold.fire,37);assert.equal(r.body.cash,Math.round((1e6-price*37)*100)/100);
  assert.equal((await T(14,-1)).status,200);assert.equal(P(x.db).hold.fire,23);
  assert.equal((await T(24,-1)).status,409);                                   // 持股不足
  for(const bad of [0,-5,2.5,100001,"10",null])assert.equal((await T(bad)).status,400);
  assert.equal((await T(5000)).status,200);                                    // 大量買進也只會把機率偏移推到上限
  const bias=x.db.m.get("secret/odds").data.bias.fire.v;assert.ok(bias<=.15+1e-9);
});

// ================= 買賣壓力看占全服持股的比例 / 全服持股記帳 =================
test("買賣壓力：全服 1000 股時賣 900 股重創、買賣 1 股幾乎沒影響；全服持股隨買賣與黑道清空而更新",async()=>{
  const x=mk();await x.call("/ensure-market");
  x.db.m.get("secret/odds").data.float={fire:1000};
  seed(x.db,"g1",{cash:1e6,hold:{fire:900}});seed(x.db,"g2",{cash:1e6,hold:{fire:100}});
  const T=(shares,dir)=>x.call("/trade",{stockId:"fire",dir,shares});
  const bias=()=>x.db.m.get("secret/odds").data.bias.fire.v;
  assert.equal((await T(1,1)).status,200);assert.ok(Math.abs(bias()-.0003)<1e-9);                       // 買 1 股：+0.03 個百分點
  assert.equal(x.db.m.get("secret/odds").data.float.fire,1001);
  assert.equal((await T(901,-1)).status,200);assert.equal(bias(),-.15);                                 // 賣 901 股：重創（碰到下限 −15）
  assert.equal(x.db.m.get("secret/odds").data.float.fire,100);
  // 黑道清空持股 → 從全服持股扣掉
  x.state.uid="g2";x.db.m.get("players/g2").data.loan={p:500,t:x.t.v};x.t.v+=25*H;
  assert.equal((await T(1,1)).body.error.code,"mob");assert.equal(x.db.m.get("secret/odds").data.float.fire,0);
});
test("全服持股：第一次沒有紀錄時，掃描玩家持股建立；持股太少時以 100 股當分母",async()=>{
  const x=mk();await x.call("/ensure-market");seed(x.db,"g1",{cash:1e6,hold:{fire:30}});seed(x.db,"g2",{cash:1e6,hold:{fire:20,water:5}});
  assert.equal("float" in x.db.m.get("secret/odds").data,false);
  assert.equal((await x.call("/trade",{stockId:"fire",dir:-1,shares:10})).status,200);
  assert.deepEqual(x.db.m.get("secret/odds").data.float,{fire:40,water:5});                              // 50 − 10；水不變
  assert.ok(Math.abs(x.db.m.get("secret/odds").data.bias.fire.v+.3*10/100)<1e-9);                       // 全服只有 50 股 → 以 100 為分母：−3 個百分點
});

test("買賣壓力：很多小單會疊加（不因單筆小於 0.5 個百分點被當成 0）",async()=>{
  const x=mk();await x.call("/ensure-market");
  x.db.m.get("secret/odds").data.float={fire:10000};seed(x.db,"g1",{cash:1e6,hold:{fire:5000}});
  for(let i=0;i<10;i++)await x.call("/trade",{stockId:"fire",dir:-1,shares:100});                    // 每筆只占 1% → -0.3 個百分點，連賣 10 筆
  const v=x.db.m.get("secret/odds").data.bias.fire.v;assert.ok(v<-.03&&v>-.032,String(v));   // 賣出時全服持股一直減少，分母變小，所以比 0.03 略多一點
});

// ================= 搶銀行／搶玩家被捕也能保釋 =================
test("保釋：搶銀行失敗被捕後可以借貸保釋出獄；保釋後可正常行動",async()=>{
  const x=mk({rand:()=>.99});await x.call("/ensure-market");seed(x.db,"g1",{cash:50000});
  const r=await x.call("/blackmarket",{action:"rob-bank"});assert.equal(r.body.caught,true);assert.ok(P(x.db).jailUntil>x.t.v);
  assert.equal((await x.call("/trade",TR())).status,403);                                    // 服刑中不能行動
  assert.equal((await x.call("/blackmarket",{action:"rob-bank"})).status,403);
  const b=await x.call("/bank",{action:"bail"});assert.equal(b.status,200);assert.equal(b.body.bail,80);
  assert.equal(P(x.db).jailUntil,0);assert.equal(P(x.db).cash,50000-5000-10000);              // 罰金照扣，保釋金不進口袋
  assert.equal((await x.call("/trade",TR())).status,200);
});

// ================= 練金工坊：買基礎元素、三物合成 =================
const CR=(x,body)=>x.call("/craft",body);
test("練金工坊：買基礎元素（10 元一個）；現金不足、蒸氣／雷不能買、數量不合法都被擋",async()=>{
  const x=mk();await x.call("/ensure-market");seed(x.db,"g1",{cash:100});
  const r=await CR(x,{action:"buy",element:"fire",qty:3});assert.equal(r.status,200);assert.equal(r.body.cost,30);
  assert.deepEqual([P(x.db).cash,P(x.db).inv.fire],[70,3]);
  assert.equal((await CR(x,{action:"buy",element:"steam",qty:1})).status,400);
  for(const q of [0,-1,1.5,101,"3"])assert.equal((await CR(x,{action:"buy",element:"fire",qty:q})).status,400);
  assert.equal((await CR(x,{action:"buy",element:"water",qty:8})).status,409);                      // 80 > 70
  assert.equal(P(x.db).cash,70);
  assert.equal((await CR(x,{action:"dance"})).status,400);
});
test("練金工坊：三物合成消耗 3 個、產出 1 個；記下已發現的配方；材料不夠不能合成",async()=>{
  const x=mk();await x.call("/ensure-market");seed(x.db,"g1",{cash:1000,inv:{fire:2,water:1,wind:1,earth:1}});
  const r=await CR(x,{action:"craft",items:["water","fire","fire"]});assert.equal(r.status,200);
  assert.equal(r.body.result,"steam");assert.equal(r.body.isNew,true);assert.equal(r.body.recipe,"fire+fire+water");
  assert.deepEqual(P(x.db).inv,{wind:1,earth:1,steam:1});assert.equal(P(x.db).recipes["fire+fire+water"],"steam");assert.equal(P(x.db).crafts,1);
  const r2=await CR(x,{action:"craft",items:["steam","wind","earth"]});assert.equal(r2.body.result,"thunder");assert.deepEqual(P(x.db).inv,{thunder:1});
  assert.equal((await CR(x,{action:"craft",items:["fire","fire","fire"]})).status,409);              // 沒有火了
  for(const bad of [[],["fire"],["fire","fire"],["fire","fire","gold"],"fire+fire+fire",null])assert.equal((await CR(x,{action:"craft",items:bad})).status,400);
  assert.deepEqual(P(x.db).inv,{thunder:1});                                                         // 失敗的請求不扣材料
  // 重複同一配方不算新發現
  P(x.db).inv.fire=2;P(x.db).inv.water=1;x.db.m.get("players/g1").data.inv={fire:2,water:1};
  assert.equal((await CR(x,{action:"craft",items:["fire","fire","water"]})).body.isNew,false);
});
test("練金工坊：完整流程 買材料 → 合成蒸氣 → 投入蒸氣（滿額 +5 個百分點），背包扣光；服刑中不能操作",async()=>{
  const x=mk();await x.call("/ensure-market");seed(x.db,"g1",{cash:100});x.state.noSeed=true;
  await CR(x,{action:"buy",element:"fire",qty:2});await CR(x,{action:"buy",element:"water",qty:1});
  assert.equal((await CR(x,{action:"craft",items:["fire","fire","water"]})).body.result,"steam");
  const r=await x.call("/inject",{stockId:"steam"});assert.equal(r.status,200);assert.equal(r.body.tier,"crafted");
  assert.ok(Math.abs(BIAS(x.db,"steam")-.05)<1e-9);assert.equal(P(x.db).inv.steam,0);assert.equal(P(x.db).cash,70);
  x.db.m.get("players/g1").data.jailUntil=x.t.v+H;
  assert.equal((await CR(x,{action:"buy",element:"fire",qty:1})).status,403);
});
