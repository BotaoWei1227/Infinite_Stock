import {CFG} from "./config.js";
import {initializeApp} from "https://www.gstatic.com/firebasejs/10.14.1/firebase-app.js";
import {getAuth,onAuthStateChanged,GoogleAuthProvider,signInWithPopup,signInWithRedirect,getRedirectResult,signOut} from "https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js";
import {getFirestore,collection,doc,onSnapshot,query,orderBy,limit} from "https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js";

const REDIRECT=location.origin+location.pathname; // 必須與 Developer Center 的 Redirect URI 完全一致
const $=id=>document.getElementById(id),S=sessionStorage;
const fmt=n=>(Math.round(n*100)/100).toFixed(2);
let hinting=true;
const say=t=>{hinting=false;$("msg").textContent=t;};
let db,auth,user=null,me={cash:CFG.startCash,hold:{},name:"訪客"},stocks={},token=null,inv=[],item=null,profile=null,busy=false,offP=null,collapsed=new Set(),view="trade",bankBuilt=false,isDev=false,devText="",odds=null,skew=0,newsList=[],newsErr=false,nf=null,oddsTick=0;

// ---------- OAuth：Authorization Code + PKCE S256（瀏覽器端） ----------
const b64u=b=>btoa(String.fromCharCode(...b)).replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/,"");
const rnd=n=>{const v=new Uint8Array(n);crypto.getRandomValues(v);return b64u(v);};
async function login(){
  const verifier=rnd(32),state=rnd(24);
  const ch=b64u(new Uint8Array(await crypto.subtle.digest("SHA-256",new TextEncoder().encode(verifier))));
  S.setItem("pk",JSON.stringify({verifier,state}));
  const u=new URL(CFG.ia.base+"/oauth/authorize");
  Object.entries({response_type:"code",client_id:CFG.ia.clientId,redirect_uri:REDIRECT,scope:CFG.ia.scope,state,code_challenge:ch,code_challenge_method:"S256"}).forEach(([k,v])=>u.searchParams.set(k,v));
  location.href=u.href;
}
async function handleCallback(){
  const q=new URLSearchParams(location.search);
  if(!q.has("code")&&!q.has("error"))return;
  const pk=JSON.parse(S.getItem("pk")||"{}");S.removeItem("pk");
  const code=q.get("code"),st=q.get("state"),err=q.get("error");
  history.replaceState(null,"",location.pathname);
  if(err)return say("你已取消授權");
  if(!pk.state||st!==pk.state)return say("授權驗證失敗（state 不符），請重新登入");
  try{
    const r=await fetch(CFG.ia.base+"/developer-api/oauth/token",{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded"},
      body:new URLSearchParams({grant_type:"authorization_code",client_id:CFG.ia.clientId,code,redirect_uri:REDIRECT,code_verifier:pk.verifier})});
    const j=await r.json();if(!r.ok)throw new Error(j.code||r.status);
    token=j.access_token;setTimeout(()=>{token=null;render();say("授權已過期，請重新連結");},(j.expires_in||3600)*1000-5000);
  }catch(e){say("取得授權失敗："+e.message);}
}
async function iaGet(path,tries=3){
  for(let i=0;i<tries;i++){
    const r=await fetch(CFG.ia.base+"/developer-api/v1/"+path,{headers:{Authorization:"Bearer "+token}});
    if(r.status===429){await new Promise(s=>setTimeout(s,(2**i)*800+Math.random()*400));continue;}
    if(r.status===401){token=null;render();throw new Error("授權失效，請重新連結");}
    if(!r.ok){const j=await r.json().catch(()=>({}));throw new Error(j.code||("HTTP "+r.status));}
    return r.json();
  }
  throw new Error("請求過於頻繁，請稍後再試");
}
async function loadIA(){
  profile=await iaGet("me");const all=[];let off=0;
  while(off!=null&&all.length<500){const p=await iaGet("history?limit=100&offset="+off);all.push(...p.items);off=p.nextOffset;}
  const now=Date.now(),m=new Map(); // 只列出 24 小時內成功合成的造物（伺服器會再驗證一次）
  for(const x of all){if(x.failed||!x.result||now-x.createdAt>864e5)continue;if(!(m.get(x.result)>=x.createdAt))m.set(x.result,x.createdAt);}
  inv=[...m].map(([name,at])=>({name,at})).sort((a,b)=>b.at-a.at);
}
const okUrl=u=>{try{return new URL(u).protocol==="https:"?u:null}catch{return null}};
const icon=(e,url)=>{const s=document.createElement("span"),u=okUrl(url);s.textContent=e||"❔";
  if(u){const i=new Image();i.className="ic";i.alt="";i.loading="lazy";i.src=u;i.onload=()=>s.replaceChildren(i);}return s;};

const left=at=>{const m=Math.max(0,Math.floor((864e5-(Date.now()-at))/6e4));return m>=60?Math.floor(m/60)+" 小時":m+" 分";};
const usedBefore=name=>{const u=me.used||{};return Object.hasOwn(u,"n:"+String(name).normalize("NFKC").trim().toLowerCase())||Object.hasOwn(u,name);};   // 同一個造物只能投入一次
const el=(tag,p={},...kids)=>{const e=document.createElement(tag);
  for(const [k,v] of Object.entries(p)){if(k==="class")e.className=v;else if(k==="text")e.textContent=v;else if(k==="disabled"||k==="hidden")e[k]=!!v;else if(k.startsWith("on"))e[k]=v;else e.setAttribute(k,v);}
  e.append(...kids);return e;};
async function gLogin(){
  const p=new GoogleAuthProvider();
  try{await signInWithPopup(auth,p);}
  catch(e){
    if(e.code==="auth/popup-blocked"||e.code==="auth/operation-not-supported-in-this-environment")return signInWithRedirect(auth,p);
    if(e.code!=="auth/popup-closed-by-user"&&e.code!=="auth/cancelled-popup-request")say("Google 登入失敗："+e.code);
  }
}
function logoutIA(){token=null;inv=[];item=null;profile=null;render();}

// ---------- 伺服器端行動（Worker 驗證 IA 身分並計算行情） ----------
async function act(name,data){
  if(busy)return null;if(!user){say("請先以 Google 帳號登入");return null;}if(name==="inject"&&!token&&!isDev){say("投入造物需要先連結《無限煉製》帳號");return null;}
  busy=true;say("處理中…");render();
  try{
    const r=await fetch(CFG.api+"/"+name,{method:"POST",headers:{Authorization:"Bearer "+await user.getIdToken(),"Content-Type":"application/json"},body:JSON.stringify({...data,iaToken:token})});
    const j=await r.json().catch(()=>({}));
    if(!r.ok)throw new Error(j.error?.message||("HTTP "+r.status));
    return j;
  }
  catch(e){if(/授權失效/.test(e.message)){token=null;}say(e.message);return null;}
  finally{busy=false;render();}
}
const REL={direct:"直接相關",strong:"高度相關",weak:"勉強相關",none:"無關"};
async function inject(id){
  if(!token&&!isDev)return say("投入造物需要先連結《無限煉製》帳號（買賣與銀行不用）");
  const typed=isDev?devText.trim():"",itemName=typed||item?.name;
  if(!itemName)return say(isDev?"請選擇造物，或在上方輸入造物名稱":"請先選擇要投入的造物");
  if(!S.getItem("gk")){say("請先到右上角 ⚙ 設定 Google API Key");$("settings").showModal?.();return;}
  const r=await act("inject",{stockId:id,itemName,geminiKey:S.getItem("gk")});
  if(r){item=null;say(`相似度 ${r.score}${REL[r.relation]?"（"+REL[r.relation]+"）":""}：${r.reason}｜${r.pass?`超過門檻 ${r.threshold}，提高`:`沒超過門檻 ${r.threshold}，降低`}${stocks[id]?.name||""}的上漲機率${r.up!=null?`（現在 ${r.up}%・僅開發者可見）`:""}`);render();}
}
const trade=async(id,dir)=>{const r=await act("trade",{stockId:id,dir});if(r)say(`已${dir>0?"買入":"賣出"} 1 股${stocks[id]?.name||""}`);};
// 上漲機率只有開發者看得到：資料放在伺服器的私密文件，開發者才能用 /odds 取得（一般玩家的瀏覽器裡根本沒有這些資料）
const DECAY_MS=3e5,DECAY=.9;   // 機率提升每 5 分鐘只剩 90%（須與伺服器 worker/src/logic.js 一致）
const nowS=()=>Date.now()+skew;
const effOddsC=rec=>{if(!rec||!rec.v)return 0;const e=rec.v*Math.pow(DECAY,Math.max(0,nowS()-rec.at)/DECAY_MS);return Math.abs(e)<.005?0:e;};
const shiftC=id=>{let x=0;for(const e of odds?.events||[])if(e.until>nowS())x+=(e.shift&&e.shift[id])||0;return x;};
const upPct=id=>Math.round(Math.min(.9,Math.max(.1,.5+effOddsC(odds?.bias?.[id])+shiftC(id)))*100);
function refreshGauges(){   // 兩次更新之間，機率條也會慢慢回到 50%
  if(!isDev||!odds)return;
  document.querySelectorAll(".gi").forEach(i=>{i.style.width=upPct(i.dataset.id)+"%";});
  document.querySelectorAll(".gp").forEach(b=>{b.textContent=upPct(b.dataset.id)+"%";});
}
async function fetchOdds(){
  if(!isDev||!user)return;
  try{
    const r=await fetch(CFG.api+"/odds",{method:"POST",headers:{Authorization:"Bearer "+await user.getIdToken()}});
    if(!r.ok)return;
    const j=await r.json();odds=j;skew=j.now-Date.now();render();
  }catch{}
}
const DAYMS=864e5,RATE=.05,MOB_LIMIT=100;
// 存款（須與伺服器 worker/src/logic.js 一致）：活存日利率 0.4%；定存日利率 1.2%、鎖 3 天，到期自動轉入活存
const DEM_RATE=.004,TD_RATE=.012,TD_DAYS=3;
const grow=(r,ms)=>Math.pow(1+r,Math.max(0,ms)/DAYMS);
const demValueC=(dem,now)=>dem&&dem.a>0?dem.a*grow(DEM_RATE,now-dem.t):0;
const tdEndC=td=>td.t+TD_DAYS*DAYMS;
const tdValueC=(td,now)=>td.p*grow(TD_RATE,Math.min(now,tdEndC(td))-td.t);
function settleC(d,now){
  let dem=d.dem&&d.dem.a>0?{a:d.dem.a,t:d.dem.t}:{a:0,t:now};const live=[],done=[];
  for(const td of d.tds||[])(tdEndC(td)<=now?done:live).push(td);
  done.sort((x,y)=>tdEndC(x)-tdEndC(y));
  for(const td of done){const T=tdEndC(td);dem={a:demValueC(dem,T)+tdValueC(td,T),t:T};}
  return {dem:{a:demValueC(dem,now),t:now},tds:live};
}
const depositsNow=()=>{const n=Date.now(),s=settleC(me,n);return s.dem.a+s.tds.reduce((a,t)=>a+tdValueC(t,n),0);};
const overAtClient=()=>{const l=me.loan;if(!l||!(l.p>0))return null;if(owedNow()<=MOB_LIMIT)return null;if(l.over!=null)return l.over;if(l.p>=MOB_LIMIT)return l.t;return l.t+DAYMS*Math.log(MOB_LIMIT/l.p)/Math.log(1+RATE);};
const mobDueClient=()=>{const o=overAtClient();return o!=null&&Date.now()-o>=DAYMS;};
const hmLeft=ms=>{const m=Math.max(0,Math.ceil(ms/6e4));return m>=60?Math.floor(m/60)+" 小時 "+(m%60)+" 分":m+" 分";};
let checking=false;
function checkMob(){if(checking||!user||!mobDueClient())return;checking=true;act("bank",{action:"check"}).finally(()=>{checking=false;});}
const owedNow=()=>{const l=me.loan;return l&&l.p>0?l.p*Math.pow(1+RATE,Math.max(0,Date.now()-l.t)/DAYMS):0;};
const net=()=>me.cash+Object.entries(me.hold||{}).reduce((a,[k,n])=>a+n*(stocks[k]?.price||0),0)-owedNow()+depositsNow();
const bankAct=async(action,amount,all)=>{const r=await act("bank",{action,amount,all});
  if(r){say(action==="borrow"?`已借入 ${fmt(amount)}，目前欠款 ${fmt(r.owed)}`:(r.owed>0?`已還款，剩餘欠款 ${fmt(r.owed)}`:"已全額還清，沒有欠款了"));}return r;};

const winBar=(title,extra)=>el("div",{class:"bar"},el("span",{class:"tt",text:title}),...(extra||[]));
function chart(s){ // 像素折線圖：紅漲綠跌，標示最高/最低與涵蓋時間
  const pts=s.p||[s.price],n=pts.length;
  if(n<2){return el("div",{class:"chart mu",text:"走勢資料累積中…（每 2 分鐘一個點）",style:"display:grid;place-items:center"});}
  const W=300,H=84,P=8,lo=Math.min(...pts),hi=Math.max(...pts),rg=(hi-lo)||1;
  const X=i=>P+i*(W-2*P)/(n-1),Y=v=>H-P-6-(v-lo)/rg*(H-2*P-10),NS="http://www.w3.org/2000/svg";
  const svg=document.createElementNS(NS,"svg");svg.setAttribute("viewBox",`0 0 ${W} ${H}`);svg.setAttribute("class","chart");svg.setAttribute("role","img");
  svg.setAttribute("aria-label",`${s.name}股價走勢，最高 ${fmt(hi)}，最低 ${fmt(lo)}`);
  [.25,.5,.75].forEach(f=>{const g=document.createElementNS(NS,"line");g.setAttribute("x1",P);g.setAttribute("x2",W-P);g.setAttribute("y1",H*f);g.setAttribute("y2",H*f);g.setAttribute("class","gd");svg.append(g);});
  const pt=i=>X(i).toFixed(1)+","+Y(pts[i]).toFixed(1),runs=[];let run=null;
  for(let i=1;i<n;i++){ // 連續同方向的線段合成一條；持平沿用前一段的顏色
    const dir=pts[i]>pts[i-1]?1:pts[i]<pts[i-1]?-1:(run?run.dir:1);
    if(!run||run.dir!==dir){run={dir,p:[pt(i-1)]};runs.push(run);}
    run.p.push(pt(i));
  }
  runs.forEach(r=>{const ln=document.createElementNS(NS,"polyline");ln.setAttribute("points",r.p.join(" "));ln.setAttribute("class","ln "+(r.dir>0?"up":"dn"));svg.append(ln);});
  const mins=Math.round((s.t[s.t.length-1]-s.t[0])/6e4),span=mins>=60?Math.round(mins/60)+" 小時":mins+" 分鐘";
  [[fmt(hi),W-P,9,"end"],[fmt(lo),W-P,H-2,"end"],["近 "+span,P,H-2,"start"]].forEach(([t,x,y,a])=>{
    const e=document.createElementNS(NS,"text");e.setAttribute("x",x);e.setAttribute("y",y);e.setAttribute("text-anchor",a);e.setAttribute("class","lb");e.textContent=t;svg.append(e);});
  return svg;
}
function renderStrip(){
  const s=$("strip");s.replaceChildren();
  const chip=(ok,label,on)=>el("button",{class:"chip "+(ok?"ok":"todo"),type:"button",onclick:on},el("i",{class:"dot","aria-hidden":"true"}),el("span",{text:label}));
  s.append(
    chip(!!user,user?"Google："+(user.displayName||user.email||"已登入"):"以 Google 帳號登入",()=>{if(user){if(confirm("登出 Google？"))signOut(auth);}else gLogin();}),
    chip(!!token,token?"工坊："+(profile?.workshopName||"已連結"):"連結《無限煉製》帳號",()=>{if(token){if(confirm("中斷《無限煉製》連線？"))logoutIA();}else login();}),
    el("div",{class:"stat"},el("span",{class:"k",text:"現金 "}),el("b",{text:fmt(me.cash)}),el("span",{class:"k",text:"　淨值 "}),el("b",{text:fmt(net())})));
}
let craftSig="";
function renderCraft(){
  const sig=JSON.stringify([!!token,isDev,inv.map(x=>x.name),Object.keys(me.used||{}),item&&item.name,busy]);
  if(sig===craftSig)return;craftSig=sig;
  const w=$("craft");w.replaceChildren(winBar("📦 CREATION.EXE",[el("span",{class:"wb dec","aria-hidden":"true",text:"_"}),el("span",{class:"wb dec","aria-hidden":"true",text:"×"})]));
  const b=el("div",{class:"body"});
  if(!token&&!isDev){b.append(el("p",{class:"mu",text:"先連結《無限煉製》帳號，才能挑選 24 小時內做出的造物來投入。"}));}
  if(token){
    const sel=el("select",{class:"px-sel","aria-label":"選擇要投入的造物"});
    sel.append(new Option(inv.length?"▼ 選擇 24 小時內做出的造物":"24 小時內沒有新做出的造物",""));
    inv.forEach((x,i)=>{const u=usedBefore(x.name),o=new Option(`${x.name}（${u?"已投入過":"剩 "+left(x.at)}）`,String(i));o.disabled=!!u;sel.append(o);});
    sel.value=item&&inv.includes(item)&&!usedBefore(item.name)?String(inv.indexOf(item)):"";
    sel.onchange=()=>{item=inv[sel.value]||null;};
    b.append(sel,el("p",{class:"mu",text:"每個造物只能投入一次，不能重複；選好後，到想影響的股票視窗按「投入造物」。"}));
  }
  if(isDev)b.append(el("label",{class:"lbl",for:"devitem",text:"🛠 開發者：自己打字輸入造物（有填就優先使用，不需要連結《無限煉製》）"}),
    el("input",{class:"px-in",id:"devitem",type:"text",maxlength:"60",autocomplete:"off",placeholder:"例如：蒸氣龍",value:devText,oninput:e=>{devText=e.target.value;}}));
  w.append(b);
}
function renderMarket(){
  const mk=$("market");mk.replaceChildren();
  const ids=Object.keys(stocks).sort();
  if(!ids.length){mk.append(el("p",{class:"mu",text:"行情載入中…"}));return;}
  for(const id of ids){
    const s=stocks[id],open=!collapsed.has(id),first=(s.p&&s.p[0])||s.price,ch=(s.price/first-1)*100,chTxt=(ch>=0?"+":"")+ch.toFixed(2)+"%";
    const n=me.hold?.[id]||0;
    const w=el("section",{class:"win stock"+(open?"":" shut"),"aria-label":s.name});
    w.append(winBar(`${s.emoji} ${id.toUpperCase()}.EXE`,[
      ...(open?[]:[el("span",{class:"bt "+(ch>=0?"up":"dn"),text:`${fmt(s.price)} ${chTxt}`})]),
      el("button",{class:"wb",type:"button","aria-label":(open?"收合 ":"展開 ")+s.name,"aria-expanded":String(open),text:open?"_":"▢",
        onclick:()=>{open?collapsed.add(id):collapsed.delete(id);renderMarket();}}),
      el("span",{class:"wb dec","aria-hidden":"true",text:"×"})]));
    const b=el("div",{class:"body"});
    b.append(
      el("div",{class:"hd"},el("span",{class:"nm",text:s.name}),el("span",{class:"px big",text:fmt(s.price)}),el("span",{class:"chg "+(ch>=0?"up":"dn"),text:chTxt})),
      chart(s),
      ...(isDev&&odds?[el("div",{class:"meter"},el("span",{class:"k",text:"上漲機率 🔒"}),el("div",{class:"gauge","aria-hidden":"true"},el("i",{class:"gi","data-id":id,style:`width:${upPct(id)}%`})),el("b",{class:"gp","data-id":id,text:upPct(id)+"%"}))]:[]),
      el("div",{class:"mu",text:`持有 ${n} 股${s.last?"｜上次投入："+s.last:""}`}),
      el("div",{class:"acts"},
        el("button",{class:"px-btn",type:"button",disabled:busy,text:"買 1",onclick:()=>trade(id,1)}),
        el("button",{class:"px-btn",type:"button",disabled:busy,text:"賣 1",onclick:()=>trade(id,-1)}),
        el("button",{class:"px-btn pri",type:"button",disabled:busy,text:"投入造物",onclick:()=>inject(id)})));
    w.append(b);mk.append(w);
  }
}

// ---------- 財經新聞 ----------
// 玩家只看得到：名稱、內容、時間、普發現金。活動對機率的影響只有開發者看得到。
function newsTime(n){const t=n.at?.toDate?.();return t?t.toLocaleString("zh-TW",{month:"numeric",day:"numeric",hour:"2-digit",minute:"2-digit",hour12:false}):"";}
const fxText=e=>Object.entries(e.shift||{}).map(([id,x])=>`${stocks[id]?.name||id} ${x>0?"+":"−"}${Math.round(Math.abs(x)*100)}`).join("、");
function updateNewsTimes(){document.querySelectorAll(".ntime").forEach(s=>{const left=Number(s.dataset.end)-nowS();s.textContent=left>0?"進行中・剩 "+hmLeft(left):"已結束";});}
function newsWin(n){
  const active=n.endsAt>nowS(),claimed=!!(me.claims&&Object.hasOwn(me.claims,n.id)),ev=(odds?.events||[]).find(e=>e.id===n.id);
  const w=el("section",{class:"win news"+(active?"":" ended"),"aria-label":n.title});
  w.append(winBar("📰 "+n.title,[el("span",{class:"wb dec","aria-hidden":"true",text:"_"}),el("span",{class:"wb dec","aria-hidden":"true",text:"×"})]));
  const b=el("div",{class:"body"});
  b.append(el("div",{class:"meta"},document.createTextNode(`${newsTime(n)}　`),el("span",{class:"ntime","data-end":String(n.endsAt),text:active?"進行中":"已結束"})));
  if(n.body)b.append(el("div",{class:"nbody",text:n.body}));
  if(n.cash>0)b.append(el("div",{class:"cash"},el("span",{text:`💰 普發現金：每人 ${fmt(n.cash)}`}),
    claimed?el("b",{class:"mu",text:"✓ 已領取"}):active?el("button",{class:"px-btn pri",type:"button",disabled:busy,text:"領取",onclick:()=>claimCash(n)}):el("span",{class:"mu",text:"已結束"})));
  if(isDev){
    if(ev)b.append(el("div",{class:"fxinfo",text:`🔒 活動影響（只有你看得到）：${fxText(ev)}`}));
    if(active)b.append(el("button",{class:"px-btn sm",type:"button",disabled:busy,text:"提前結束活動",onclick:()=>endNews(n)}));
  }
  w.append(b);return w;
}
async function claimCash(n){const r=await act("news",{action:"claim",id:n.id});if(r)say(`已領取普發現金 ${fmt(r.amount)}`);}
async function endNews(n){if(!confirm(`提前結束「${n.title}」？活動的機率影響會立刻消失。`))return;const r=await act("news",{action:"end",id:n.id});if(r){say("已提前結束活動");fetchOdds();}}
let newsSig="";
function renderNews(){
  const form=$("nform");
  if(isDev&&!form.firstChild)buildNewsForm(form);
  if(!isDev&&form.firstChild){form.replaceChildren();nf=null;}
  if(nf)syncEffRows();
  const sig=JSON.stringify([newsList.map(n=>[n.id,n.endsAt>nowS(),!!(me.claims&&Object.hasOwn(me.claims,n.id))]),isDev,(odds?.events||[]).map(e=>e.id),newsErr,busy,!!user]);
  const list=$("nlist");
  if(sig!==newsSig){
    newsSig=sig;list.replaceChildren();
    if(newsErr)list.append(el("p",{class:"warn",text:"新聞載入失敗。請確認 Firestore 規則已更新（需要允許讀取 news 集合）。"}));
    else if(!newsList.length)list.append(el("p",{class:"mu",text:"目前沒有任何新聞。"}));
    newsList.forEach(n=>list.append(newsWin(n)));
  }
  updateNewsTimes();
}
// 開發者發布表單：只建一次，不會因為行情更新而被清掉正在輸入的內容
function buildNewsForm(host){
  nf={title:el("input",{class:"px-in",id:"ntitle",maxlength:"40",placeholder:"活動名稱（最多 40 字）","aria-label":"活動名稱"}),
    body:el("textarea",{class:"px-in",id:"nbody",rows:"4",maxlength:"600",placeholder:"活動資料（可留空；只寫文字也行，例如前情公告）","aria-label":"活動資料"}),
    dur:el("input",{class:"px-in",id:"ndur",type:"number",inputmode:"decimal",min:"1",value:"1","aria-label":"活動持續時間"}),
    unit:el("select",{class:"px-sel","aria-label":"時間單位"},new Option("分鐘","1"),new Option("小時","60"),new Option("天","1440")),
    cash:el("input",{class:"px-in",id:"ncash",type:"number",inputmode:"decimal",min:"0",step:"0.01",placeholder:"0（不發就留空）","aria-label":"普發現金"}),
    box:el("div"),eff:{},sig:""};
  nf.unit.value="60";
  const w=el("section",{class:"win","aria-label":"發布活動"});
  w.append(winBar("🛠 PUBLISH.EXE",[el("span",{class:"wb dec","aria-hidden":"true",text:"_"}),el("span",{class:"wb dec","aria-hidden":"true",text:"×"})]));
  w.append(el("div",{class:"body"},
    el("p",{class:"mu",text:"只有開發者看得到這個表單。活動影響與機率只有你看得到，玩家只會看到名稱、內容、時間與現金。"}),
    el("label",{class:"lbl",for:"ntitle",text:"活動名稱"}),nf.title,
    el("label",{class:"lbl",for:"nbody",text:"活動資料"}),nf.body,
    el("label",{class:"lbl",for:"ndur",text:"活動持續時間"}),el("div",{class:"unit"},nf.dur,nf.unit),
    el("h2",{class:"h2",text:"活動影響（可個別選擇）"}),
    el("p",{class:"mu",text:"活動期間，把該股票「上漲的基準機率」改成 50+x（漲）或 50−x（跌）；x 是 1～40 的整數。不選＝不影響。"}),
    nf.box,
    el("label",{class:"lbl",for:"ncash",text:"普發現金（每位玩家領一次，活動期間內有效）"}),nf.cash,
    el("div",{class:"row"},el("button",{class:"px-btn pri",type:"button",text:"發布活動",onclick:publishNews}))));
  host.append(w);syncEffRows();
}
function syncEffRows(){
  const ids=Object.keys(stocks).sort(),sig=ids.join(",");
  if(sig===nf.sig)return;nf.sig=sig;nf.box.replaceChildren();
  for(const id of ids){
    const sel=el("select",{class:"px-sel","aria-label":`${stocks[id].name} 的影響`},new Option("— 無","0"),new Option("▲ 漲 +x","1"),new Option("▼ 跌 −x","-1"));
    const num=el("input",{class:"px-in",type:"number",inputmode:"numeric",min:"1",max:"40",step:"1",value:"10",disabled:true,"aria-label":`${stocks[id].name} 的 x（百分點）`});
    sel.onchange=()=>{num.disabled=sel.value==="0";};
    nf.eff[id]={sel,num};nf.box.append(el("div",{class:"fx"},el("span",{text:`${stocks[id].emoji} ${stocks[id].name}`}),sel,num));
  }
}
async function publishNews(){
  const title=nf.title.value.trim(),mins=parseFloat(nf.dur.value)*parseFloat(nf.unit.value),cash=parseFloat(nf.cash.value)||0,effects={};
  if(!title)return say("請輸入活動名稱");
  if(!(mins>=1))return say("請輸入活動持續時間");
  for(const [id,c] of Object.entries(nf.eff)){const dir=Number(c.sel.value);if(!dir)continue;const x=parseInt(c.num.value);if(!(x>=1&&x<=40))return say("活動影響的 x 要是 1～40 的整數");effects[id]=dir*x;}
  const r=await act("news",{action:"publish",title,body:nf.body.value,durationMin:mins,effects,cash});
  if(r){say(`已發布活動「${title}」`);nf.title.value="";nf.body.value="";nf.cash.value="";nf.dur.value="1";nf.unit.value="60";for(const c of Object.values(nf.eff)){c.sel.value="0";c.num.disabled=true;c.num.value="10";}fetchOdds();}
}
// ---------- 銀行 ----------
const bk={},sv={};
function buildBank(){
  const v=$("v-bank");v.replaceChildren();
  const w=el("section",{class:"win","aria-label":"銀行"});
  w.append(winBar("🏦 BANK.EXE",[el("span",{class:"wb dec","aria-hidden":"true",text:"_"}),el("span",{class:"wb dec","aria-hidden":"true",text:"×"})]));
  const b=el("div",{class:"body"});
  const hr=((Math.pow(1+RATE,1/24)-1)*100).toFixed(2);
  bk.owed=el("b");bk.cash=el("b");bk.mob=el("b");bk.next=el("b");bk.times=el("p",{class:"mu"});
  bk.amt=el("input",{class:"px-in",type:"number",inputmode:"decimal",min:"0.01",step:"0.01",placeholder:"金額",id:"bamt","aria-label":"金額"});
  bk.b1=el("button",{class:"px-btn pri",type:"button",text:"借款",onclick:()=>{const a=parseFloat(bk.amt.value);if(!(a>0))return say("請輸入金額");bankAct("borrow",a).then(r=>{if(r)bk.amt.value="";});}});
  bk.b2=el("button",{class:"px-btn",type:"button",text:"還款",onclick:()=>{const a=parseFloat(bk.amt.value);if(!(a>0))return say("請輸入金額");bankAct("repay",a).then(r=>{if(r)bk.amt.value="";});}});
  bk.b3=el("button",{class:"px-btn",type:"button",text:"全額還清",onclick:()=>bankAct("repay",0,true)});
  b.append(
    el("p",{class:"mu",text:`高利貸：利率 5%／24 小時（約每小時 ${hr}%，利息持續複利累計），想借多少都行。`}),
    el("div",{class:"grid"},
      el("div",{class:"cell debt"},el("span",{class:"k",text:"目前欠款"}),bk.owed),el("div",{class:"cell"},el("span",{class:"k",text:"現金"}),bk.cash),
      el("div",{class:"cell"},el("span",{class:"k",text:"黑道上門倒數"}),bk.mob),el("div",{class:"cell debt"},el("span",{class:"k",text:"24 小時後欠款"}),bk.next)),
    el("label",{class:"lbl",for:"bamt",text:"金額"}),bk.amt,el("div",{class:"row"},bk.b1,bk.b2,bk.b3),
    el("p",{class:"warn",text:`欠款會從淨值扣掉。欠款超過 ${MOB_LIMIT} 並連續超過 24 小時，黑道就會上門：資產清空，只能重新開始。借來的錢可以拿去買股票，但股價可能跌。`}),bk.times);
  w.append(b);v.append(w);buildSavings(v);bankBuilt=true;
}
async function depAct(action,{all=false,at}={}){
  const a=parseFloat(sv.amt.value),needs=["dem_in","dem_out","td_in"].includes(action)&&!all;
  if(needs&&!(a>0))return say("請輸入金額");
  if(action==="td_break"&&!confirm("提前解約只退回本金，利息會作廢，確定嗎？"))return;
  const r=await act("bank",{action,amount:needs?a:undefined,all,at});
  if(r){say({dem_in:`已存入活存 ${fmt(a)}`,dem_out:all?"已領出全部活存":`已領出活存 ${fmt(a)}`,td_in:`已存入定存 ${fmt(a)}（鎖 ${TD_DAYS} 天）`,td_break:"已提前解約，退回本金（利息作廢）"}[action]);
    if(action!=="td_break")sv.amt.value="";}
}
function buildSavings(v){
  const w=el("section",{class:"win","aria-label":"存款"});
  w.append(winBar("💰 SAVINGS.EXE",[el("span",{class:"wb dec","aria-hidden":"true",text:"_"}),el("span",{class:"wb dec","aria-hidden":"true",text:"×"})]));
  sv.dem=el("b");sv.td=el("b");sv.sum=el("b");sv.day=el("b");sv.list=el("ul",{class:"list"});sv.sig="";
  sv.amt=el("input",{class:"px-in",type:"number",inputmode:"decimal",min:"0.01",step:"0.01",placeholder:"金額",id:"samt","aria-label":"存款金額"});
  const btn=(label,action,extra,pri)=>el("button",{class:"px-btn"+(pri?" pri":""),type:"button",text:label,onclick:()=>depAct(action,extra)});
  sv.btns=[btn("存入活存","dem_in",{},true),btn("領出活存","dem_out"),btn("全部領出","dem_out",{all:true}),btn(`存入定存（${TD_DAYS} 天）`,"td_in")];
  w.append(el("div",{class:"body"},
    el("p",{class:"mu",text:`活存：日利率 ${DEM_RATE*100}%，隨時存取。定存：日利率 ${TD_RATE*100}%，鎖 ${TD_DAYS} 天，到期自動轉入活存；提前解約只退本金，利息作廢。`}),
    el("div",{class:"grid"},
      el("div",{class:"cell"},el("span",{class:"k",text:"活存餘額"}),sv.dem),el("div",{class:"cell"},el("span",{class:"k",text:"定存（含利息）"}),sv.td),
      el("div",{class:"cell"},el("span",{class:"k",text:"存款總額"}),sv.sum),el("div",{class:"cell"},el("span",{class:"k",text:"每日利息（估）"}),sv.day)),
    el("label",{class:"lbl",for:"samt",text:"金額"}),sv.amt,el("div",{class:"row"},...sv.btns),
    el("h2",{class:"h2",text:"定存明細"}),sv.list));
  v.append(w);
}
function updateSavings(){
  const now=Date.now(),s=settleC(me,now),tdv=s.tds.map(t=>tdValueC(t,now)),tdTotal=tdv.reduce((a,x)=>a+x,0);
  sv.dem.textContent=fmt(s.dem.a);sv.td.textContent=fmt(tdTotal);sv.sum.textContent=fmt(s.dem.a+tdTotal);sv.day.textContent=fmt(s.dem.a*DEM_RATE+tdTotal*TD_RATE);
  const sig=JSON.stringify(s.tds.map(t=>t.t));
  if(sig!==sv.sig){sv.sig=sig;sv.list.replaceChildren();sv.rows=s.tds.map(t=>{
    const span=el("span",{class:"mu"});
    sv.list.append(el("li",{},span,el("button",{class:"px-btn sm",type:"button",text:"提前解約","aria-label":"提前解約這筆定存，只退本金",onclick:()=>depAct("td_break",{at:t.t})})));
    return span;});
    if(!s.tds.length)sv.list.append(el("li",{},el("span",{class:"mu",text:"目前沒有定存"})));}
  s.tds.forEach((t,i)=>{sv.rows[i].textContent=`本金 ${fmt(t.p)}｜目前 ${fmt(tdv[i])}｜到期剩 ${hmLeft(tdEndC(t)-now)}`;});
  sv.btns.forEach(b=>{b.disabled=busy;});sv.list.querySelectorAll("button").forEach(b=>{b.disabled=busy;});
}
function updateBank(){
  if(!bankBuilt)buildBank();
  updateSavings();
  const o=owedNow();bk.owed.textContent=fmt(o);bk.cash.textContent=fmt(me.cash);
  bk.next.textContent=fmt(o*(1+RATE));
  const ov=overAtClient(),left_=ov==null?0:ov+DAYMS-Date.now();
  bk.mob.textContent=ov==null?`安全（≤${MOB_LIMIT}）`:left_<=0?"⚠ 黑道已在門口":"⚠ "+hmLeft(left_);bk.mob.className=ov==null?"":"hot";
  bk.times.textContent=me.bankrupt>0?`你被黑道找上過 ${me.bankrupt} 次。`:"";
  bk.b1.disabled=bk.b2.disabled=bk.b3.disabled=busy;bk.b2.disabled=busy||o<.005;bk.b3.disabled=busy||o<.005;
}
// ---------- 練金工坊 ----------
function renderWork(){
  const v=$("v-work");v.replaceChildren();
  const w=el("section",{class:"win","aria-label":"練金工坊"});
  w.append(winBar("⚗ WORKSHOP.EXE",[el("span",{class:"wb dec","aria-hidden":"true",text:"_"}),el("span",{class:"wb dec","aria-hidden":"true",text:"×"})]));
  const b=el("div",{class:"body"});
  b.append(el("p",{class:"warn",text:"這裡目前只讀取你在《無限煉製》的合成紀錄，列出 24 小時內做出的造物。代為合成需要官方提供的合成介面，尚未接上。"}));
  b.append(el("h2",{class:"h2",text:"你 24 小時內做出的造物"}));
  if(!token)b.append(el("p",{class:"mu",text:"連結《無限煉製》帳號後，這裡會列出你做出的造物，以及哪些還能投入股票。"}));
  else if(!inv.length)b.append(el("p",{class:"mu",text:"24 小時內沒有新做出的造物。到遊戲裡煉成新東西吧！"}));
  else{const ul=el("ul",{class:"list"});
    inv.forEach(x=>{const u=usedBefore(x.name);ul.append(el("li",{},el("span",{class:u?"off":"",text:x.name}),el("span",{class:"mu",text:u?"已投入過":"剩 "+left(x.at)+"・可投入"})));});
    b.append(ul);}
  w.append(b);v.append(w);
}
// ---------- 設定（介面大小） ----------
const SCALES={s:["小",.9],m:["中",1],l:["大",1.2]};
let scaleKey="m";
try{const k=localStorage.getItem("ui");if(SCALES[k])scaleKey=k;}catch{}
const applyScale=()=>document.documentElement.style.setProperty("--zoom",String(SCALES[scaleKey][1]));
function renderSet(){
  const v=$("v-set");v.replaceChildren();
  const w=el("section",{class:"win","aria-label":"設定"});
  w.append(winBar("⚙ SETTINGS.EXE",[el("span",{class:"wb dec","aria-hidden":"true",text:"_"}),el("span",{class:"wb dec","aria-hidden":"true",text:"×"})]));
  const seg=el("div",{class:"seg",role:"group","aria-label":"介面大小"});
  Object.entries(SCALES).forEach(([k,[name]])=>seg.append(el("button",{class:"px-btn",type:"button","aria-pressed":String(k===scaleKey),text:name,
    onclick:()=>{scaleKey=k;try{localStorage.setItem("ui",k);}catch{}applyScale();renderSet();}})));
  w.append(el("div",{class:"body"},el("h2",{class:"h2",text:"介面大小"}),seg,
    el("h2",{class:"h2",text:"Google API Key"}),el("p",{class:"mu",text:"AI 判定造物時使用你自己的 Key；也可以按右上角的 ⚙。"}),
    el("button",{class:"px-btn",type:"button",text:"開啟 API 設定",onclick:()=>$("settings").showModal()})));
  v.append(w);
}
// ---------- 分頁 ----------
const VIEWS={trade:"v-trade",news:"v-news",bank:"v-bank",work:"v-work",set:"v-set"},HASH={trade:"",news:"#news",bank:"#bank",work:"#work",set:"#settings"};
function setView(v){
  if(!VIEWS[v])v="trade";view=v;
  for(const [k,id] of Object.entries(VIEWS))$(id).hidden=k!==v;
  document.querySelectorAll(".nav-item").forEach(b=>{if(b.dataset.v===v)b.setAttribute("aria-current","page");else b.removeAttribute("aria-current");});
  try{history.replaceState(null,"",location.pathname+location.search+HASH[v]);}catch{}
  render();window.scrollTo(0,0);
}
function render(){
  if(hinting)$("msg").textContent=!user?"請先登入 Google 帳號，就能買賣股票與使用銀行":isDev&&view==="trade"?"開發者模式：可以在造物視窗直接打字輸入造物名稱":!token?"買賣與銀行可以直接玩；連結《無限煉製》帳號才能投入造物":view==="bank"?"借來的錢可以拿去買股票，但利息一直在滾，記得還款":view==="trade"?"選一個 24 小時內做出的造物，再到想影響的股票視窗按「投入造物」":"";
  renderStrip();
  if(view==="trade"){renderCraft();renderMarket();}
  else if(view==="news")renderNews();
  else if(view==="bank")updateBank();
  else if(view==="work")renderWork();
  else renderSet();
}
function wireNav(){
  const dr=$("drawer");
  $("menu").onclick=()=>dr.showModal();$("dclose").onclick=()=>dr.close();
  dr.addEventListener("click",e=>{if(e.target===dr)dr.close();});
  dr.querySelectorAll(".nav-item").forEach(b=>b.onclick=()=>{dr.close();setView(b.dataset.v);});
  setInterval(()=>{refreshGauges();if(isDev&&++oddsTick%4===0)fetchOdds();if(view==="news")updateNewsTimes();checkMob();if(view==="bank"&&document.activeElement!==bk.amt&&document.activeElement!==sv.amt){renderStrip();updateBank();}},5000);
}
function renderFeed(rows){
  const f=$("feed");f.replaceChildren();
  if(!rows.length)f.append(el("div",{class:"mu",text:"還沒有人投入造物"}));
  rows.forEach(x=>{const t=x.at?.toDate?.();const hm=t?t.toLocaleTimeString("zh-TW",{hour:"2-digit",minute:"2-digit",hour12:false}):"";
    if(x.mob){f.append(el("div",{class:"mob"},document.createTextNode(`☠ ${x.who} 欠款 ${fmt(x.owed)} 拖過一天，被黑道找上門，資產清空重新開始`)));return;}
    f.append(el("div",{class:(x.pass!=null?x.pass:x.pct!=null?x.pct>0:x.score>=50)?"up":"dn"},el("span",{class:"tm",text:hm}),
      document.createTextNode(`${x.who}${x.dev?" 🛠":""} 將「${x.item}」投入 ${x.stock}：相似度 ${x.score}${x.pass!=null?(x.pass?" ✓":" ✗"):""}${x.pct!=null?"，"+(x.pct>0?"+":"")+x.pct+"%":""}`)));});
}
function wireSettings(){
  const dlg=$("settings"),k=$("gkey"),upd=()=>{$("keystate").textContent=S.getItem("gk")?"✓ 已設定（只存在這個分頁）":"尚未設定";};
  k.value=S.getItem("gk")||"";$("model").textContent=CFG.modelLabel;upd();
  $("gear").onclick=()=>dlg.showModal();
  $("close").onclick=()=>dlg.close();
  dlg.addEventListener("click",e=>{if(e.target===dlg)dlg.close();});
  k.onchange=()=>{S.setItem("gk",k.value.trim());upd();};
  $("clearkey").onclick=()=>{S.removeItem("gk");k.value="";upd();};
}

// ---------- 啟動 ----------
async function main(){
  applyScale();wireSettings();wireNav();
  setView({"#news":"news","#bank":"bank","#work":"work","#settings":"set"}[location.hash]||"trade");
  if([CFG.firebase.apiKey,CFG.ia.clientId,CFG.api].some(v=>/REPLACE_ME/.test(v))){say("請先在 config.js 填入 Firebase、Client ID 與 Worker 網址");return;}
  const app=initializeApp(CFG.firebase);db=getFirestore(app);
  auth=getAuth(app);getRedirectResult(auth).catch(e=>say("Google 登入失敗："+e.code));
  onAuthStateChanged(auth,u=>{
    user=u;isDev=false;craftSig="";offP&&offP();offP=null;
    if(u)u.getIdToken().then(t=>fetch(CFG.api+"/whoami",{method:"POST",headers:{Authorization:"Bearer "+t}})).then(r=>r.json()).then(j=>{isDev=!!j.dev;craftSig="";render();if(isDev)fetchOdds();}).catch(()=>{});
    if(u)offP=onSnapshot(doc(db,"players",u.uid),snap=>{me=snap.exists()?{...snap.data()}:{cash:CFG.startCash,hold:{},name:u.displayName||"玩家"};render();checkMob();});
    else me={cash:CFG.startCash,hold:{},name:"訪客"};
    render();
  });
  await handleCallback();
  onSnapshot(doc(db,"market","state"),snap=>{
    if(!snap.exists()){fetch(CFG.api+"/ensure-market",{method:"POST"}).catch(()=>{});return;}
    stocks=snap.data().stocks||{};render();});
  onSnapshot(query(collection(db,"news"),orderBy("at","desc"),limit(30)),snap=>{newsList=[];snap.forEach(d=>newsList.push({id:d.id,...d.data()}));newsErr=false;render();},()=>{newsErr=true;render();});
  onSnapshot(query(collection(db,"feed"),orderBy("at","desc"),limit(15)),snap=>{const rows=[];snap.forEach(d=>rows.push(d.data()));renderFeed(rows);});
  if(token)loadIA().then(render).catch(e=>say(e.message));
}
main();
